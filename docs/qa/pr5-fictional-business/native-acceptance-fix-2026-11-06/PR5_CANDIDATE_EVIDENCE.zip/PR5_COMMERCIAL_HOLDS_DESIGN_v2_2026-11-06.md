# PR #5 commercial hold identity design v2 — closure review

Source pin: `6b7a04e949e4ed69019591acab9f616107348b7c`. PO-approved target: two explicit, deterministic commercial obligation identities in a controlled priced-offer run, even if `RUN_STATE.blockers` contains only a generic AI sentence. No schema, role, service or new mode.

## Data flow and scope

`BRIEF.requested_artifacts` and `RUN_STATE.artifacts/tasks` determine whether this is a controlled priced-offer route. The new ready-mode floor applies, at **any stage**, if either: (a) the BRIEF requests canonical `output/PRICING.md` (accept `PRICING.md` through existing `_request_key`), (b) a manifest artifact safely resolves to that canonical path, or (c) an active `sub-pricing` task has mode `final_feasibility`. It runs even if phase is HELD or the pricing task was omitted. A standalone hooks request and direct/offline CRO diagnosis have none of these records and incur no new obligation. An offline *paid offer* still has a pricing request or task, so it remains covered.

After normal schema parsing, the read-only checker takes `OFFER_DECISIONS.fields` as the authoritative statuses, values, `authorization_ref` strings and evidence references. It emits two distinct ready-mode findings, each with a stable code and fixed identity wording, independently of any generic blocker:

- `COMMERCIAL_REFUND_CANCELLATION_UNRESOLVED`: **refund/cancellation terms unresolved**, followed by failing field keys/statuses.
- `COMMERCIAL_COST_FEASIBILITY_UNVERIFIED`: **delivery costs and financial feasibility unverified**, followed by failing field keys/statuses.

The checker never rewrites inputs, claims owner authorization is genuine, claims profitability is proved, or clears an existing blocker. Existing `BLOCKER_OPEN`, declared business-validation, artifact-review and aggregate-review findings remain additive. Root instruction: for each unresolved identity, put that explicit wording in `RUN_STATE.blockers`, CHECKPOINT and QA_REPORT; a compound blocker is acceptable if it names both. The checker still derives the identity when root fails to register it. The first-completion acceptance counts identity visibility, not a universal number of findings.

## Closed field table

Publish this same table in `references/commercial-feasibility.md` and point to it from `references/orchestration.md`. `OFFER_DECISIONS` schema already permits named fields, so no schema change is required.

| Obligation | Canonical fields | Existing aliases accepted | Resolution rule |
| --- | --- | --- | --- |
| Refund terms | `refunds` | `refund_cancellation`, `refund_policy` | Every present canonical/alias source must be approved, non-null/nonempty, with nonempty `authorization_ref`. If none is present, hold. |
| Cancellation terms | `cancellation` | `refund_cancellation`, `cancellation_terms`, `renewal/cancellation_terms` | Same all-of rule. A documented nonapplicable rule for a one-time purchase still needs owner approval; absence does not mean no policy. |
| Delivery cost | `delivery_cost` | `fulfillment_cost` | Every present source must be approved money with non-null structured value, nonempty `authorization_ref` and at least one evidence reference. If none is present, hold. `delivery` is scope, not a cost alias. |
| Price input to feasibility | `price` | none; `price_anchor` is **not** approval | Require approved money value and nonempty `authorization_ref`; a proposed anchor leaves cost/feasibility held. |
| Feasibility conclusion | `financial_feasibility` | none | Require approved, nonempty value, nonempty `authorization_ref` and at least one evidence reference. This is a structured owner decision, not proof of net profit. |
| Other declared cost inputs | `acquisition_cost`, `CAC`, `overhead`, `overhead_allocation`, `taxes`, `refund_cost`, `refund_costs`, `refund_cost_and_treatment`, `guarantee_cost`, `affiliate_commission`, `payment_fees`, `support_cost/capacity` | exact keys only; no name-pattern inference | If present, each must be approved with a non-null/nonempty value; otherwise cost/feasibility stays held. Missing optional keys are covered by the feasibility conclusion's evidence obligation, not invented as specific zero costs. |

The table is closed: exact keys only, no free-text matching or substring classification. If both a canonical key and alias appear, **all** present sources must resolve; no precedence or guessed contradiction detector can hide an unresolved status. The checker can verify only nonempty authorization and evidence references, never their external authenticity. Existing semantic review remains responsible for whether the cost evidence actually establishes feasibility.

## Failure-mode matrix

| Input under applicable priced route | Derived result |
| --- | --- |
| Missing refund/cancellation source, null/unknown status, proposed/held/superseded term, or approved term without nonempty authorization reference | Policy finding naming the failed exact keys/statuses. |
| Canonical approved but legacy combined term held | Policy finding; all-of rule preserves the hold. |
| Missing `delivery_cost`/`fulfillment_cost`, null/unknown cost, proposed cost, wrong money shape, missing evidence or authorization | Cost/feasibility finding naming the defect; unknown is not zero. |
| `price_anchor` proposed without approved `price`, or missing/unknown `financial_feasibility` | Cost/feasibility finding; proposed price is not owner-approved. |
| Any present closed-table cost key unknown/proposed/held | Cost/feasibility finding; no open-ended field-name heuristic. |
| Approved, nonempty owner-referenced policy; approved money price/cost; approved evidence-referenced feasibility; no present unresolved cost keys | Neither new finding; existing validation/review holds remain, and no commercial release is implied. |
| Stage E with PRICING requested (existing r1 credit fixture) | Both checks apply despite stage E. |
| Standalone hooks or direct/offline CRO without pricing request/artifact/task | No new checks. |
| Full paid offer whose conversion surface is offline | Both checks apply if pricing is requested/artifact/task. |
| Generic AI blocker or already HELD phase | Both findings still derive from structured fields. |

## Compatibility and tests

The immutable PR #3 archive uses `refund_cancellation: held` and unknown acquisition/overhead/tax/refund costs. Replay must retain its original seven identities; new derived policy and cost findings may increase the count but must not remove any old blocker. The DeskFern first-run C records use `refunds`, `cancellation` and `delivery_cost: unknown`, a proposed `price_anchor`, and no `financial_feasibility`; both findings must derive without editing that archive. Existing four schemas, five specialist roles, 17 method bodies, SUMMARY contract and CRO routing stay intact. Focused deterministic tests cover each failure-mode row, read-only behavior and the nonapplicable counterexamples. Full QA and Windows/Ubuntu CI follow. A fresh installed C native run uses the **unchanged** DeskFern prompt, freezes first completion before checker, and requires both commercial identities, business validation, three canonical artifact review holds and aggregate review blocker without operator repair.

## Changes from v1 in response to independent review

1. Closed field table goes into checker and commercial-feasibility reference, with orchestration pointer.
2. Removed open-ended cost-name inference; only exact known keys are inspected.
3. Applicability follows pricing request/artifact/task at every stage, including existing stage E fixture.
4. `authorization_ref` is checked as a nonempty string; canonical and legacy overlap uses an all-of rule rather than an inferred contradiction judgment.
