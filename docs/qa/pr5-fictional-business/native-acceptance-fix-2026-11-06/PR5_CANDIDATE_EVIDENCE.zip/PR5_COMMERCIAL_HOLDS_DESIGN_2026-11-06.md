# PR #5 commercial hold identity design — review draft

Pinned source: `6b7a04e949e4ed69019591acab9f616107348b7c`. Defect: C's `OFFER_DECISIONS.json` contains `refunds`, `cancellation`, `delivery_cost` as `unknown`, yet the checker only repeats a generic AI-authored commercial blocker. Six findings remain HELD but two accepted obligation identities lose explicit checker wording.

## Smallest data flow

`BRIEF.stage` + `BRIEF.requested_artifacts` + active `RUN_STATE.tasks` → full priced-offer applicability → existing `OFFER_DECISIONS.fields` statuses, values, owner authorization and evidence → two deterministic, read-only ready-mode findings. The checker neither edits records nor treats any finding as approval. It runs even if `RUN_STATE.phase == HELD` and regardless of existing generic blockers.

Applicability: stage A, B or D **and** a canonical `output/PRICING.md` request (accept either `PRICING.md` or `output/PRICING.md` through existing safe path normalization) **and** an active `sub-pricing/final_feasibility` task. Standalone hooks, direct CRO, stage C copy-only and stage E focused work do not enter this new floor. A requested full priced-offer route with missing pricing task already fails the existing route check; the new floor should also apply based on the requested PRICING artifact so the omitted task cannot suppress commercial holds. A task-only full priced-offer run with a completed final-feasibility task also applies. Thus scope is A/B/D and (pricing requested **or** active final-feasibility task). An unrelated stage A intake with neither is outside this narrow floor.

Policy identity uses canonical `refunds` and `cancellation` decision fields. The existing combined `refund_cancellation` field is accepted as a legacy source for both only when neither canonical field exists; a canonical field and combined field that conflict stays held. Each applicable policy field is resolved only when `status=approved`, `value` is non-null/non-empty and `authorization_ref` identifies an actual owner decision. `unknown`, `proposed`, `held`, `superseded`, missing, or contradictory statuses mean **refund/cancellation terms unresolved**. A one-time offer still needs an authorized cancellation rule such as “not applicable to a completed one-time purchase”; a free/no-priced-offer route is outside applicability.

Cost/feasibility identity uses canonical `delivery_cost` (`fulfillment_cost` accepted as a legacy alias only if canonical absent), plus `financial_feasibility` and approved price/price-anchor decisions. A verified delivery cost is an approved money value with nonempty evidence and owner authorization; `null` is unknown, never zero. `financial_feasibility` is approved only with a nonempty conclusion value, evidence references and owner authorization. Existing declared cost fields, if present, cannot remain unknown/proposed/held while feasibility is called resolved. A merely proposed `price_anchor` does not count as an approved price. If any prerequisite fails, the finding says **delivery costs and financial feasibility unverified**, naming the precise missing/unknown/unapproved fields without inventing a cost or claim. The checker does not infer real profitability from a record that structurally passes.

The root records explicit holds in `RUN_STATE.blockers`, `CHECKPOINT.md` and `QA_REPORT.md` for each applicable unresolved identity. A compound state blocker is allowed only when it explicitly names both identities. The checker derives the two findings from structured statuses regardless of model wording, so a missing or generic state blocker cannot hide either identity. It does not rewrite the blocker array. Existing `BLOCKER_OPEN`, business-validation and independent-review findings remain additive; no finding count is hardcoded.

## Failure-mode matrix

| Full priced-offer input | Policy finding | Cost/feasibility finding |
| --- | --- | --- |
| Missing required decision field/status | Hold, name missing policy field | Hold, name missing cost/price/feasibility field |
| Refund/cancellation unknown or `null` | Hold | Unchanged |
| Refund/cancellation proposed, held or approved without owner reference | Hold | Unchanged |
| Delivery cost unknown/`null` or approved without evidence | Unchanged | Hold |
| Price anchor proposed or price missing | Unchanged | Hold |
| Other declared cost input unknown | Unchanged | Hold |
| Approved policy and evidence-backed cost/feasibility, no declared unknown costs | No new policy finding | No new cost finding; not a commercial-release approval |
| Conflicting canonical and legacy policy/cost fields | Hold | Hold as applicable; contradictions cannot clear |
| Standalone hooks, stage C copy-only, direct/offline CRO | No new finding | No new finding |
| Full paid offer with offline conversion surface | Normal policy gate | Normal cost gate; offline does not waive commercial terms |
| BRIEF business-validation declaration or missing independent sales review | Existing business/review holds remain | Existing business/review holds remain |

## Compatibility and acceptance

Use existing schemas (arbitrary named decision fields), task roles, paths, checker and references; add no role, mode, service, schema version or dependency. Existing 17 standalone method bodies and five specialists remain untouched. The prior immutable PR #3 archive must still show all seven identity obligations; added explicit derived findings may change its total count but must not remove original blockers. The SUMMARY contract and automatic CRO routing remain unchanged. A fresh native C run from the **unchanged prompt** must archive first completion before checker and show both commercial identities plus business-validation and four review obligations in the first-completion checker output. The checker remains read-only, and no operator record repair is allowed.

## Open review questions

1. Is requiring a dedicated `financial_feasibility` decision unnecessarily heavy when the existing pricing output and unknown cost fields suffice? Recommend retaining it only if needed to prevent a falsely clear cost gate.
2. Should an absent full-route pricing task still trigger the commercial floor from the BRIEF request? Recommend yes, as stated.
3. Does the legacy combined policy field need explicit contradiction handling when canonical fields coexist? Recommend yes, because silently preferring one source could clear an unresolved hold.
