"""Run one pinned PR #5 native Codex turn and freeze its first completion."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent
PACKET = ROOT / "packet"
EVIDENCE = ROOT / "evidence" / "sessions"
WORKSPACES = Path("C:/Users/Admin/Hormozi-PR5-Native-2026-11-06")
MODEL = "gpt-6.1-sol"
EFFORT = 'model_reasoning_effort="medium"'
PROMPTS = {
    "A1": "A1_BEGINNER.txt",
    "A2": "A2_OWNER_FACTS.txt",
    "A2R": "A2_OWNER_FACTS.txt",
    "B": "B_EXPERT_HOOKS.txt",
    "C": "C_FULL_OFFER_NO_CRO_WORD.txt",
    "D": "D_DIRECT_CRO.txt",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=PROMPTS)
    args = parser.parse_args()
    case = args.case
    key = case[0]
    workspace = WORKSPACES / key
    evidence = EVIDENCE / key
    evidence.mkdir(parents=True, exist_ok=True)
    suffix = "_first" if case == "A1" else "_owner" if case == "A2" else "_owner_retry" if case == "A2R" else ""
    prefix = case.lower() + suffix
    events = evidence / (prefix + "_events.jsonl")
    stderr = evidence / (prefix + "_stderr.txt")
    reply = evidence / ("owner_followup_reply.txt" if case.startswith("A2") else "first_reply.txt")
    receipt_path = evidence / (prefix + "_receipt.json")
    assert workspace.is_dir() and not events.exists() and not receipt_path.exists()
    prompt = (PACKET / "fixtures" / "prompts" / PROMPTS[case]).read_text(encoding="utf-8").strip()
    if case == "C":
        assert all(word not in prompt.lower() for word in ("cro", "conversion optimization", "post-click"))
    if case.startswith("A2"):
        first = json.loads((evidence / "a1_first_receipt.json").read_text(encoding="utf-8"))
        assert first["exit_code"] == 0 and first["thread_ids"]
        command = ["codex", "exec", "resume", "--skip-git-repo-check", "--json", "-o", str(reply), "-m", MODEL,
                   "-c", EFFORT, first["thread_ids"][0], "-"]
    else:
        command = ["codex", "exec", "-C", str(workspace), "--skip-git-repo-check", "-s",
                   "workspace-write", "-m", MODEL, "-c", EFFORT, "--json", "-o", str(reply), "-"]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    timed_out = False
    with events.open("w", encoding="utf-8") as out, stderr.open("w", encoding="utf-8") as err:
        process = subprocess.Popen(command, cwd=workspace, stdin=subprocess.PIPE, stdout=out,
                                   stderr=err, text=True, encoding="utf-8", creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            process.communicate(prompt, timeout=600)
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
            process.wait(timeout=30)
    lines = events.read_text(encoding="utf-8").splitlines()
    parsed = []
    for line in lines:
        try:
            parsed.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    threads = [e.get("thread_id") for e in parsed if e.get("type") == "thread.started"]
    usage = [e.get("usage") for e in parsed if e.get("type") == "turn.completed"]
    errors = [e for e in parsed if e.get("type") in ("error", "turn.failed")]
    capture_dir = evidence / ("owner_followup_retry_completion" if case == "A2R" else
                              "owner_followup_completion" if case == "A2" else "first_completion")
    capture = subprocess.run(["python", str(PACKET / "scripts" / "capture_first_completion.py"),
                              "--workspace", str(workspace), "--out", str(capture_dir)],
                             capture_output=True, text=True)
    files = {}
    full_zip = evidence / (prefix + "_workspace.zip")
    with ZipFile(full_zip, "w", ZIP_DEFLATED) as archive:
        for path in sorted(workspace.rglob("*")):
            if path.is_file() and not path.is_symlink():
                rel = path.relative_to(workspace).as_posix()
                data = path.read_bytes()
                files[rel] = sha256(data)
                archive.writestr(rel, data)
    receipt = {
        "case": case, "source_sha": "6b7a04e949e4ed69019591acab9f616107348b7c",
        "workspace": str(workspace), "prompt_file": PROMPTS[case], "prompt_sha256": sha256(prompt.encode()),
        "command": command, "started_utc": started, "elapsed_seconds": round(time.monotonic() - tick, 2),
        "exit_code": process.returncode, "timed_out": timed_out, "thread_ids": threads,
        "usage_events": usage, "error_events": errors, "reply_sha256": sha256(reply.read_bytes()) if reply.exists() else None,
        "first_workspace_files": files, "full_workspace_zip_sha256": sha256(full_zip.read_bytes()),
        "packet_capture_exit": capture.returncode, "packet_capture_stdout": capture.stdout,
        "packet_capture_stderr": capture.stderr,
    }
    receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({k: receipt[k] for k in ("case", "elapsed_seconds", "exit_code", "timed_out", "thread_ids",
                                           "usage_events", "reply_sha256", "packet_capture_stdout")}, ensure_ascii=True))
    return 0 if process.returncode == 0 and capture.returncode == 0 and not timed_out else 1


if __name__ == "__main__":
    raise SystemExit(main())
