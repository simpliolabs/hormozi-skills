"""Package immutable PR5 native acceptance evidence for the PR comment."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
items = sorted(
    [p for base in (root / "evidence", root / "packet") for p in base.rglob("*") if p.is_file()]
    + [root / name for name in ("run_native.py", "compile_report.py", "package_evidence.py", "INSTALL_OPERATIONS.json")]
)
manifest = {
    "tested_source_sha": "6b7a04e949e4ed69019591acab9f616107348b7c",
    "files": {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in items},
}
manifest_path = root / "EVIDENCE_MANIFEST.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
archive = root / "PR5_NATIVE_ACCEPTANCE_EVIDENCE_2026-11-06.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.write(manifest_path, "EVIDENCE_MANIFEST.json")
    for p in items:
        z.write(p, p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    bad = z.testzip()
    assert bad is None, bad
print(json.dumps({"archive": str(archive), "files": len(items) + 1, "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))
