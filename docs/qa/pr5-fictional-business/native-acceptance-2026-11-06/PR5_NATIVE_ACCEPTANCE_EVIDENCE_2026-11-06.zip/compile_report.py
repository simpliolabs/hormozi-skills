"""Compile operator observations from immutable PR5 native test receipts."""

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EV = ROOT / "evidence"
SHA = "6b7a04e949e4ed69019591acab9f616107348b7c"
TEMPLATE = ROOT / "packet/templates/ACCEPTANCE_MATRIX.csv"


def data(path):
    return json.loads((EV / path).read_text(encoding="utf-8"))


receipts = {
    "A": data("sessions/A/a1_first_receipt.json"),
    "B": data("sessions/B/b_receipt.json"),
    "C": data("sessions/C/c_receipt.json"),
    "D": data("sessions/D/d_receipt.json"),
}

status = {
    "P01": "PASS", "P02": "PASS", "P03": "PASS", "P04": "PASS",
    "A01": "PASS", "A02": "PASS", "A03": "PASS", "A04": "PASS", "A05": "PASS",
    "B01": "PASS", "B02": "PASS", "B03": "PASS", "B04": "PASS", "B05": "PASS",
    "C01": "PASS", "C02": "PASS", "C03": "PASS", "C04": "PASS", "C05": "PASS", "C06": "PASS", "C07": "FAIL", "C08": "PASS", "C09": "PASS", "C10": "PASS", "C11": "PASS", "C12": "PASS", "C13": "PASS", "C14": "PASS",
    "D01": "PASS", "D02": "PASS", "D03": "PASS", "D04": "PASS", "D05": "PASS", "D06": "PASS", "D07": "PASS",
    "E01": "PASS", "E02": "PASS", "E03": "PASS", "E04": "PASS", "E05": "PASS",
}

paths = {
    "PRE": "preflight.json; INSTALLED_SOURCE_VERIFICATION.json; local_qa/run_local_qa.json",
    "A": "sessions/A/a1_first_receipt.json; sessions/A/first_reply.txt; sessions/A/a1_first_events.jsonl; sessions/A/a2r_owner_retry_receipt.json",
    "B": "sessions/B/b_receipt.json; sessions/B/first_reply.txt; sessions/B/b_events.jsonl",
    "C": "sessions/C/c_receipt.json; sessions/C/first_reply.txt; sessions/C/first_completion/first_completion.zip; sessions/C/checker_ready_stdout.txt",
    "D": "sessions/D/d_receipt.json; sessions/D/first_reply.txt; sessions/D/d_workspace.zip",
    "ALL": "ACCEPTANCE_MATRIX.csv; TOKEN_LEDGER.csv; FINAL_DECISION.md",
}

notes = {
    "A04": "Owner follow-up was a genuine same-thread model turn after a failed CLI resume attempt. The corrected resume was read-only; no Stage A artifact write was tested.",
    "C05": "Unknown refund/cancellation and delivery economics are disclosed in SUMMARY/PRICING, but not explicitly named together in the structured commercial blocker; see C07.",
    "C07": "FAIL: RUN_STATE commercial blocker says only 'Commercial terms and financial feasibility require owner approval and evidence'; unlike archived fixture it does not identify refund/cancellation and unknown costs explicitly. Review floor identities remain visible.",
    "C08": "Three artifact findings plus one aggregate review blocker; attempted native dispatch was refused, so no independent sales-copy review occurred.",
    "C09": "Prompt did not ask for CRO; native command events show CRO skill/framework/waterfall reads and CRO_REVIEW.md first completion.",
    "C12": "First-completion archive was captured before read-only checker; post_checker_hash_check.json reports zero changed files.",
    "D07": "Native browser use was denied; native response explicitly disclaimed rendered QA. Separate operator Chrome rendering observed 650px mobile overflow but did not save screenshots.",
    "E02": "Cross-family reviewer was requested separately; no independent sales-copy approval is claimed. See INDEPENDENT_REVIEW.md for actual review outcome.",
    "E04": "Pinned local QA 327 tests, one platform skip; exact-SHA CI Windows and Ubuntu were green at preflight. Refresh CI status at PR-post boundary.",
}

with TEMPLATE.open(newline="", encoding="utf-8-sig") as source, (EV / "ACCEPTANCE_MATRIX.csv").open("w", newline="", encoding="utf-8") as target:
    reader = csv.DictReader(source)
    writer = csv.DictWriter(target, fieldnames=reader.fieldnames)
    writer.writeheader()
    for row in reader:
        row["result"] = status[row["id"]]
        row["evidence_file"] = paths[row["case"]]
        row["developer_notes"] = notes.get(row["id"], "First completion inspected; see case session record and frozen archive.")
        writer.writerow(row)

with (EV / "TOKEN_LEDGER.csv").open("w", newline="", encoding="utf-8") as target:
    fields = ["case", "step", "requested_model", "observed_model", "requested_effort", "observed_effort", "input_tokens", "cached_input_tokens", "output_tokens", "reasoning_output_tokens", "wall_seconds", "evidence_source", "notes"]
    writer = csv.DictWriter(target, fieldnames=fields)
    writer.writeheader()
    for case, receipt in receipts.items():
        use = receipt["usage_events"][-1]
        writer.writerow({"case": case, "step": "first_completion", "requested_model": "gpt-6.1-sol", "observed_model": "gpt-6.1-sol", "requested_effort": "medium", "observed_effort": "medium", "input_tokens": use["input_tokens"], "cached_input_tokens": use["cached_input_tokens"], "output_tokens": use["output_tokens"], "reasoning_output_tokens": use["reasoning_output_tokens"], "wall_seconds": receipt["elapsed_seconds"], "evidence_source": f"sessions/{case}/{Path({'A':'a1_first','B':'b','C':'c','D':'d'}[case] + '_receipt.json').name}; native rollout turn_context", "notes": "Host usage counters; no cost estimate or per-skill allocation."})
    follow = data("sessions/A/a2r_owner_retry_receipt.json")
    use = follow["usage_events"][-1]
    writer.writerow({"case": "A", "step": "owner_followup_corrected_resume", "requested_model": "gpt-6.1-sol", "observed_model": "gpt-6.1-sol", "requested_effort": "medium", "observed_effort": "medium", "input_tokens": use["input_tokens"], "cached_input_tokens": use["cached_input_tokens"], "output_tokens": use["output_tokens"], "reasoning_output_tokens": use["reasoning_output_tokens"], "wall_seconds": follow["elapsed_seconds"], "evidence_source": "sessions/A/a2r_owner_retry_receipt.json; native rollout turn_context", "notes": "Same thread; corrected CLI resume. Earlier A2 invocation failed before model turn."})

case_descriptions = {
    "A": ("PASS", "Natural language entry loaded orchestrator and adaptive routing, then asked exactly one useful question. Owner follow-up stayed concise and did not invent validation. Corrected resume was read-only, so checkpoint persistence and complete novice journey remain unproven."),
    "B": ("PASS", "Exactly five hooks; only hormozi-hooks method loaded; no offer waterfall, state ledger or CRO artifact."),
    "C": ("FAIL", "A provisional offer and automatic CRO readiness preflight were produced; SUMMARY contract passed and checker held sales outputs. First-completion structured commercial blocker omitted explicit refund/cancellation and unknown-cost identities, so seven-hold criterion fails. No independent sales-copy review ran."),
    "D": ("PASS", "Direct CRO method loaded; diagnosed source-backed overflow, delayed submit, dead sign-in and unsupported proof, while respecting synthetic analytics limits. Native browser rendering was refused; operator independently rendered mobile and desktop viewport measurements without a saved screenshot."),
}

loads = {
    "A": "hormozi-orchestrator/SKILL.md, references/adaptive-routing.md",
    "B": "hormozi-hooks/SKILL.md only",
    "C": "orchestrator, market-research, hormozi-offer, audit-offer, value-perception, pricing-strategy, pitch, hooks, landing-page-copy, cro-page-optimizer; shared evidence/commercial/CRO refs",
    "D": "cro-page-optimizer/SKILL.md, CRO_FRAMEWORK.md, evidence-contract.md",
}

for case, receipt in receipts.items():
    decision, explanation = case_descriptions[case]
    output_capture = data(f"sessions/{case}/first_completion/first_completion_hashes.json")
    lines = [
        f"# PR #5 native session {case}", "",
        f"- Decision: **{decision}**",
        f"- Source: `{SHA}`; installed plugin file tree byte matched this checkout.",
        f"- Host: Codex CLI 0.164.0-alpha.11.1; fresh isolated workspace `{receipt['workspace']}`.",
        f"- Thread: `{receipt['thread_ids'][0]}`; started `{receipt['started_utc']}`; elapsed {receipt['elapsed_seconds']} seconds; exit {receipt['exit_code']}.",
        f"- Prompt: `{receipt['prompt_file']}` SHA256 `{receipt['prompt_sha256']}`.",
        f"- Model/effort: requested and native turn_context observed `gpt-6.1-sol` / `medium`.",
        f"- Skill reads observed in native command events: {loads[case]}.",
        f"- First reply: `sessions/{case}/first_reply.txt` SHA256 `{receipt['reply_sha256']}`.",
        f"- First workspace ZIP SHA256 `{receipt['full_workspace_zip_sha256']}`; packet output capture: `{output_capture['status']}`.",
        f"- Usage: input {receipt['usage_events'][-1]['input_tokens']}, cached input {receipt['usage_events'][-1]['cached_input_tokens']}, output {receipt['usage_events'][-1]['output_tokens']}, reasoning output {receipt['usage_events'][-1]['reasoning_output_tokens']}. Host counters, no per-skill cost attribution.",
        "", "## Finding", "", explanation, "",
    ]
    if case == "A":
        lines += ["## Follow-up", "", "Initial A2 CLI resume failed before model execution because the skip-git-repo-check flag was missing. Failure receipt and stderr preserved. A2R resumed the same thread with the exact owner reply, exit 0; native sandbox was read-only, so no Stage A file write was verified.", ""]
    if case == "C":
        lines += ["## First-completion controls", "", "`first_completion/first_completion.zip` captured 17 output files before operator checker. Installed pinned checker returned HELD exit 1 with six findings: three BLOCKER_OPEN (business validation, generic commercial, aggregate review) and three canonical artifact independent-review findings. `post_checker_hash_check.json` shows zero first-completion file changes. Native specialist spawn was attempted and refused by model-route gate; root continued sequentially. No child or reviewer ran.", ""]
    if case == "D":
        lines += ["## Browser boundary", "", "Native Chrome computer-use permission was denied. Native model explicitly marked screenshot/render verification unassessed. Separate operator Chrome rendering measured 390px viewport versus 1040px scroll width (650px overflow); desktop 1425px client/scroll width, no overflow. No screenshot file saved.", ""]
    (EV / f"sessions/{case}/SESSION_RECORD.md").write_text("\n".join(lines), encoding="utf-8")

(EV / "sessions/D/BROWSER_RENDER_OBSERVATION.json").write_text(json.dumps({"provenance": "separate operator Chrome DevTools rendering; not native agent browser execution", "mobile": {"viewport_width_px": 390, "document_scroll_width_px": 1040, "overflow_px": 650}, "desktop": {"viewport_width_px": 1440, "document_client_width_px": 1425, "document_scroll_width_px": 1425}, "screenshot_saved": False, "native_browser_permission": "denied"}, indent=2) + "\n", encoding="utf-8")

print(f"compiled {len(status)} matrix rows, 5 usage rows, 4 session records")
