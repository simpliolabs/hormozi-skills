# PR #5 first-run session record (make a fresh copy for A, B, C, D)

**Never overwrite this blank template. Never backfill a native run that did not actually happen.**

- Case: `PENDING` (A / B / C / D)
- Exact PR source SHA: `PENDING`
- Host / version: `PENDING`
- Tested by / environment: `PENDING`
- Session start and completion times (UTC): `PENDING`
- Fresh chat and workspace verified? `PENDING`
- Prompt filename and SHA256: `PENDING`
- Scripted follow-ups (case A only): `PENDING`
- Method selection: `automatic`, `explicit`, `not observed` or `PENDING`
- Skills and required references actually loaded (with evidence): `PENDING`
- Subagent calls, tool availability/refusals and fallback: `PENDING`
- Observed models / effort (unknown if invisible): `PENDING`
- Input tokens / output tokens, with host receipt (unknown if invisible): `PENDING`
- Total wall time, source: `PENDING`
- Business facts provided and scope: `PENDING`
- Original assistant first reply saved at: `PENDING`
- First-completion zip and SHA-256 (if any): `PENDING`
- Checker command, exit and findings (if controlled full run): `PENDING`
- CRO method actually loaded? `PENDING`
- Any unsupported claim / unapproved commercial term: `PENDING`
- Seven-hold identities preserved or not applicable: `PENDING`
- Overall case decision (`PASS`, `FAIL`, `INCONCLUSIVE`): `PENDING`
- Short evidence-grounded explanation: `PENDING`

## First-completion exact artifact paths

(Populate from real workspace; do not invent.)

## Steps observed, chronological

(Host observations only, no hidden reasoning. Distinguish request from actual execution.)

## Deviations and repair recommendation

(If needed, recommend a narrow source patch and a fresh rerun. Do not edit this first-completion workspace.)
