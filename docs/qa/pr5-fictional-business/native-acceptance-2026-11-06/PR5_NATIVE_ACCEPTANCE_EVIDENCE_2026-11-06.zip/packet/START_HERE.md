# Hormozi Skills PR #5 | Developer Native Test-Drive Packet

**Status: READY TO EXECUTE. NOT YET NATIVE-TESTED OR APPROVED FOR MERGE.**

This is the actual handoff package for the developer. It is not a PR comment, not a proof-of-execution report, and not a source-code release. All test inputs are fictional. The developer should use the source checkout pinned below and return the evidence requested in this ZIP.

## Fixed target

| Setting | Required value |
| --- | --- |
| Repository | `simpliolabs/hormozi-skills` |
| PR | https://github.com/simpliolabs/hormozi-skills/pull/5 |
| **Exact test HEAD** | `6b7a04e949e4ed69019591acab9f616107348b7c` |
| Base PR | #4, documentation/visual presentation (PR #5 is stacked on #4) |
| CI already recorded at this HEAD | https://github.com/simpliolabs/hormozi-skills/actions/runs/42128049903, Ubuntu/Windows success |
| Fictional business | DeskFern Studio, weekly office-plant-care service |
| Outputs | Unedited first-completion artifacts, four native session logs, hashes, checker findings, independent reviewer conclusion, actual usage if available |
| Authorization | Testing only. **No merge, deployment, publication, commercial release, or waiver of unresolved holds.** |

**Source is pinned, not included as a full clone.** Use the Git commands below. This packet contains all acceptance instructions, test prompts, fictional data, QA scripts, scorecards, and the exact tracked-file Git blob IDs for independent source verification. `docs/SOURCE_PIN.md` distinguishes packet fixtures from tracked originals.

## Developer: start in this order

1. **Read** `docs/01_DEV_RUNBOOK.md`, then `docs/02_ACCEPTANCE_MATRIX.md`.
2. **Clone and pin** the exact PR commit (Git Bash, PowerShell, or terminal):

   ```bash
   git clone https://github.com/simpliolabs/hormozi-skills.git
   cd hormozi-skills
   git fetch origin pull/5/head:refs/remotes/origin/pr5-test
   git checkout --detach 6b7a04e949e4ed69019591acab9f616107348b7c
   git status --short
   ```

   If the exact SHA is unavailable, **STOP** and record the issue. Do not quietly substitute current `main`, latest branch head, or a release tag.
3. **Run the packet preflight from outside the checkout**:

   ```bash
   python /path/to/packet/scripts/preflight.py --repo /path/to/hormozi-skills --out /path/to/separate-evidence/preflight.json
   ```

   It verifies exact commit + tracked Git blobs and records environment details. It does not modify source.
4. **Run repeatable local tests**:

   ```bash
   python /path/to/packet/scripts/run_local_qa.py --repo /path/to/hormozi-skills --out /path/to/separate-evidence/local_qa
   ```

   Requires dependencies in the source repo's `requirements-qa.txt` (`python -m pip install -r requirements-qa.txt` from a suitable test environment). Python 3.12 is the CI target.
5. **Run FOUR FRESH NATIVE AI sessions, each with its own empty project workspace**, using the exact user prompts in `fixtures/prompts/`. Refer to `docs/03_NATIVE_SESSIONS.md`. Session A: beginner. B: focused expert. C: full offer with **NO CRO keyword in the user prompt**. D: direct CRO diagnosis with deliberately defective local demo.
6. **Immediately after EACH first completion**, before any inspection/edit/repair, freeze the workspace output:

   ```bash
   python /path/to/packet/scripts/capture_first_completion.py --workspace /path/to/session-workspace --out /path/to/separate-evidence/session_C_first
   ```

   Copy the raw first assistant response and tool/host observations separately. The capture script only archives `workspace/output/` and never edits it.
7. **Run original checker on the frozen session's untouched workspace**, where a controlled output run exists:

   ```bash
   python /path/to/hormozi-skills/scripts/check_outputs.py --workspace /path/to/session-workspace --run /path/to/session-workspace/output/runs/ACTUAL_RUN_ID --mode ready
   ```

   A HELD exit 1 is expected when obligations remain. Save stdout/stderr and exit code. Do not turn a correct hold into a pass by editing the authored files.
8. **Complete** `templates/ACCEPTANCE_MATRIX.csv`, `templates/SESSION_RECORD.md` (one per session), `templates/TOKEN_LEDGER.csv`, and `templates/INDEPENDENT_REVIEW.md`. Save files under evidence separately; templates in this ZIP remain blanks.
9. **Validate evidence completeness** with `scripts/check_evidence.py --evidence /path/to/evidence`. This checks record presence, **not** semantic correctness. Then return the zipped evidence bundle to PR #5 with an explicit recommendation: `PASS`, `FAIL`, or `INCONCLUSIVE`.

## What the developer must prove

- **A, beginner:** Natural language without skill name begins with **one useful question**, not a giant interview or 18 loaded manuals; record whether auto-discovery actually occurred.
- **B, expert:** Exactly **five** synthetic Instagram hooks. One method only, not a full offer run or CRO report.
- **C, full offer:** Selected offer/pricing/sales methods really loaded; **downstream CRO readiness automatically occurs** without a CRO request; all business and separate-review holds remain visible; canonical SUMMARY contract holds.
- **D, CRO audit:** Detects the local fixture's mobile overflow, misleading 5,000+ claim, slow silent submit, and distracting sign-in; separates verified defects from speculative A/B experiments.
- **Quality gates:** Seven legacy hold identities remain preserved, independent reviewer receipts are not invented, and token counts are **measured or explicitly unknown**, never estimated as facts.

## Where everything is

| Directory | Contents |
| --- | --- |
| `docs/` | Native operating runbook, acceptance criteria, preservation rules, evidence protocol, release recommendation, source pin |
| `fixtures/` | Fictional company brief, local HTML demo, synthetic behavior data, four literal prompts |
| `scripts/` | Git SHA/blob preflight, read-only QA harness, first-completion capture, evidence completeness checker, packet verifier |
| `templates/` | Acceptance spreadsheet CSV, reviewer template, per-session record, token ledger, defect log |
| `evidence/empty/` | Empty evidence placeholder only; **no test run has been performed** |
| `SOURCE_BLOB_MANIFEST.json` | Exact Git blob SHAs read from PR #5 at pinned HEAD |
| `PACKET_HASHES.json` | SHA-256 of included packet files, produced by builder and verified by `scripts/verify_packet.py` |

**Acceptance is not transferable from source CI.** Windows/Ubuntu checks had passed as observed when the packet was prepared. The missing piece is actual native session evidence and independent assessment.
