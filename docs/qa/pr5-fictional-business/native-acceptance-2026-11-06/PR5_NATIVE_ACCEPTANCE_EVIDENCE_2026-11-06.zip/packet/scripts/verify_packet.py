#!/usr/bin/env python3
"""Verify the packet's SHA-256 hashes. Does not fetch GitHub or run an AI host."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "PACKET_HASHES.json"


def main() -> int:
    if not INDEX.is_file():
        print("MISSING PACKET_HASHES.json")
        return 1
    data = json.loads(INDEX.read_text(encoding="utf-8"))
    fail = []
    for path, expected in data["files"].items():
        f = ROOT / path
        if not f.is_file():
            fail.append(f"MISSING {path}")
        elif hashlib.sha256(f.read_bytes()).hexdigest() != expected:
            fail.append(f"SHA256 MISMATCH {path}")
    actual = {f.relative_to(ROOT).as_posix() for f in ROOT.rglob("*") if f.is_file() and f.name != "PACKET_HASHES.json" and "__pycache__" not in f.parts}
    expected = set(data["files"])
    for name in sorted(actual - expected):
        fail.append(f"UNTRACKED PACKET FILE {name}")
    print("PACKET INTEGRITY", "PASS" if not fail else "FAIL", "files", len(expected))
    for reason in fail:
        print(reason)
    return 0 if not fail else 1


if __name__ == "__main__":
    raise SystemExit(main())
