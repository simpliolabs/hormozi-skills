#!/usr/bin/env python3
"""Check pinned Git source SHA and selected Git blob IDs without editing the checkout."""
import argparse
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

PACKET_ROOT = Path(__file__).resolve().parents[1]
MANIFEST = json.loads((PACKET_ROOT / "SOURCE_BLOB_MANIFEST.json").read_text(encoding="utf-8"))


def git(repo: Path, *args: str) -> str:
    completed = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, check=False)
    if completed.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed ({completed.returncode}): {completed.stderr.strip()}")
    return completed.stdout.strip()


def preflight(repo: Path) -> dict:
    findings: list[str] = []
    try:
        actual_sha = git(repo, "rev-parse", "HEAD")
        repo_root = git(repo, "rev-parse", "--show-toplevel")
        tracked_changes = git(repo, "status", "--porcelain", "--untracked-files=no")
    except (RuntimeError, FileNotFoundError) as exc:
        return {"status": "FAIL", "errors": [str(exc)], "source_sha": "unknown"}

    if Path(repo_root).resolve() != repo.resolve():
        findings.append(f"--repo path must be Git checkout root: {repo_root}")
    if actual_sha != MANIFEST["source_sha"]:
        findings.append(f"WRONG HEAD: expected {MANIFEST['source_sha']}, actual {actual_sha}")
    if tracked_changes:
        findings.append("Tracked checkout changes exist: " + tracked_changes[:1000])

    observed: dict[str, str] = {}
    for rel, blob in MANIFEST["blobs"].items():
        try:
            actual = git(repo, "rev-parse", f"HEAD:{rel}")
        except RuntimeError as exc:
            findings.append(f"Missing Git tracked path {rel}: {exc}")
            continue
        observed[rel] = actual
        if actual != blob:
            findings.append(f"BLOB MISMATCH {rel}: expected {blob}, actual {actual}")
    return {
        "status": "PASS" if not findings else "FAIL",
        "expected_sha": MANIFEST["source_sha"],
        "source_sha": actual_sha,
        "repo": repo_root,
        "tracked_changes": tracked_changes,
        "blob_count_verified": len(observed),
        "blob_ids": observed,
        "errors": findings,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, type=Path, help="The pinned Git checkout root")
    parser.add_argument("--out", required=True, type=Path, help="Output JSON outside the source checkout")
    args = parser.parse_args()
    repo = args.repo.resolve()
    out = args.out.resolve()
    if out == repo or repo in out.parents:
        parser.error("--out must be outside the source repository")
    result = preflight(repo)
    result["checked_at_utc"] = datetime.now(timezone.utc).isoformat()
    result["host"] = {"platform": platform.platform(), "python": sys.version, "cwd": os.getcwd()}
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"PR5 PRE-FLIGHT {result['status']}: {result.get('blob_count_verified', 0)} Git blobs checked")
    for error in result.get("errors", []):
        print("ERROR:", error)
    print("Result JSON:", out)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
