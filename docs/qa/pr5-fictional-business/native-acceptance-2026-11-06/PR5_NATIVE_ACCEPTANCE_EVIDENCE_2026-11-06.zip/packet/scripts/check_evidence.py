#!/usr/bin/env python3
"""Completeness check for developer-returned evidence, NOT a semantic acceptance oracle."""
import argparse
import csv
from pathlib import Path

REQUIRED = [
    "preflight.json",
    "local_qa/run_local_qa.json",
    "sessions/A/SESSION_RECORD.md",
    "sessions/A/first_reply.txt",
    "sessions/B/SESSION_RECORD.md",
    "sessions/B/first_reply.txt",
    "sessions/C/SESSION_RECORD.md",
    "sessions/C/first_reply.txt",
    "sessions/C/first_completion.zip",
    "sessions/C/first_completion_hashes.json",
    "sessions/C/checker_ready_stdout.txt",
    "sessions/C/checker_exit_code.txt",
    "sessions/D/SESSION_RECORD.md",
    "sessions/D/first_reply.txt",
    "TOKEN_LEDGER.csv",
    "ACCEPTANCE_MATRIX.csv",
    "INDEPENDENT_REVIEW.md",
    "FINAL_DECISION.md",
]
VALID_STATES = {"PASS", "FAIL", "INCONCLUSIVE", "NOT_RUN"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--evidence", required=True, type=Path)
    args = ap.parse_args()
    root = args.evidence.resolve()
    failures = []
    for name in REQUIRED:
        f = root / name
        if not f.is_file() or f.stat().st_size == 0:
            failures.append(f"MISSING / EMPTY: {name}")
    sheet = root / "ACCEPTANCE_MATRIX.csv"
    if sheet.is_file():
        with sheet.open(encoding="utf-8-sig", newline="") as f:
            records = list(csv.DictReader(f))
        if not records:
            failures.append("ACCEPTANCE_MATRIX has no rows")
        for row in records:
            state = (row.get("result") or "").strip().upper()
            if state not in VALID_STATES:
                failures.append(f"BAD STATUS for {row.get('id')}: {state or '(blank)'}")
            if state == "NOT_RUN":
                failures.append(f"UNFINISHED CASE {row.get('id')} (NOT_RUN)")
            if state in {"PASS", "FAIL", "INCONCLUSIVE"} and not (row.get("evidence_file") or "").strip():
                failures.append(f"MISSING EVIDENCE PATH for {row.get('id')}")
    for name in ["INDEPENDENT_REVIEW.md", "FINAL_DECISION.md"]:
        f = root / name
        if f.is_file() and "PENDING" in f.read_text(encoding="utf-8").upper():
            failures.append(f"UNFINISHED TEMPLATE: {name} still contains PENDING")
    print("Evidence completeness:", "COMPLETE FOR REVIEW" if not failures else "INCOMPLETE")
    for problem in failures:
        print(" -", problem)
    print("Note: this checks file presence only, NOT native execution validity, separate review truth, or semantic correctness.")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
