#!/usr/bin/env python3
"""Freeze an unedited controlled-run output tree without modifying the original.

Run immediately after a first completed native session, BEFORE QA/reviewer edits.
Archives only workspace/output (not private source, transcripts or home directory).
"""
import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    workspace, out = args.workspace.resolve(), args.out.resolve()
    output = workspace / "output"
    if out == workspace or workspace in out.parents:
        parser.error("--out must be OUTSIDE the native workspace to preserve first-completion integrity")
    if not workspace.is_dir():
        parser.error("workspace does not exist")
    out.mkdir(parents=True, exist_ok=True)
    manifest = {
        "source": "UNEDITED FIRST COMPLETION, as captured by local developer",
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "workspace": str(workspace),
        "output_exists": output.is_dir(),
        "files": [],
    }
    if not output.is_dir():
        manifest["status"] = "NO_OUTPUT_DIRECTORY"
        (out / "first_completion_hashes.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        print("NO_OUTPUT_DIRECTORY: wrote capture manifest, no output artifact to archive")
        return 0

    files = []
    for parent, dirs, names in os.walk(output, followlinks=False):
        dirs.sort()
        names.sort()
        for directory in dirs:
            if (Path(parent) / directory).is_symlink():
                parser.error("symlink directory in output tree; refuses to follow or misrepresent it")
        for name in names:
            f = Path(parent) / name
            if f.is_symlink() or not f.is_file():
                parser.error(f"unsupported output file (symlink/non-regular): {f}")
            files.append(f)

    zip_path = out / "first_completion.zip"
    with ZipFile(zip_path, "w", ZIP_DEFLATED, compresslevel=6) as z:
        for f in files:
            rel = f.relative_to(workspace).as_posix()
            data = f.read_bytes()
            manifest["files"].append({"path": rel, "bytes": len(data), "sha256": sha256(data)})
            z.writestr(rel, data)

    # Detect output mutation while capture was in progress instead of silently certifying it.
    changes = []
    for f, row in zip(files, manifest["files"]):
        if not f.is_file() or sha256(f.read_bytes()) != row["sha256"]:
            changes.append(row["path"])
    manifest["count"] = len(files)
    manifest["zip_sha256"] = sha256(zip_path.read_bytes())
    manifest["status"] = "PASS" if not changes else "INVALID_WORKSPACE_CHANGED_DURING_CAPTURE"
    manifest["changed_during_capture"] = changes
    (out / "first_completion_hashes.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"First-completion capture {manifest['status']}: {len(files)} files; zip sha256 {manifest['zip_sha256']}")
    return 0 if not changes else 1


if __name__ == "__main__":
    raise SystemExit(main())
