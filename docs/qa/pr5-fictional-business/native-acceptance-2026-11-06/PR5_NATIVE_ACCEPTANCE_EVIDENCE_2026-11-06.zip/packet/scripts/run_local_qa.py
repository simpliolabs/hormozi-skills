#!/usr/bin/env python3
"""Execute repository QA and read-only CRO gate demonstrations, saving logs externally.

PASS here does not certify a native model/agent invocation.
"""
import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

CASES = [
    ("unit_tests", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"]),
    ("repo_checks", [sys.executable, "scripts/check_outputs.py", "--repo", "."]),
    ("gate_A_planned", [sys.executable, "scripts/cro_gate.py", "--stage", "A", "--surface", "planned"]),
    ("gate_B_live", [sys.executable, "scripts/cro_gate.py", "--stage", "B", "--surface", "live"]),
    ("gate_D_offline", [sys.executable, "scripts/cro_gate.py", "--stage", "D", "--surface", "offline"]),
    ("gate_C_destination", [sys.executable, "scripts/cro_gate.py", "--stage", "C", "--surface", "live", "--digital-destination"]),
    ("gate_E_focused", [sys.executable, "scripts/cro_gate.py", "--stage", "E", "--surface", "live", "--focused"]),
]

EXPECTED_GATE = {
    "gate_A_planned": (True, "readiness"),
    "gate_B_live": (True, "full_page"),
    "gate_D_offline": (True, "buyer_handoff"),
    "gate_C_destination": (True, "full_page"),
    "gate_E_focused": (False, "focused_skip"),
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    if out == repo or repo in out.parents:
        parser.error("--out must be outside the source checkout")
    out.mkdir(parents=True, exist_ok=True)
    report = {"note": "Static QA only; not native AI execution", "source_repo": str(repo), "commands": []}
    all_pass = True
    for name, argv in CASES:
        start = datetime.now(timezone.utc)
        try:
            result = subprocess.run(argv, cwd=repo, capture_output=True, text=True, check=False)
            stdout, stderr, rc = result.stdout, result.stderr, result.returncode
        except OSError as exc:
            stdout, stderr, rc = "", str(exc), 127
        end = datetime.now(timezone.utc)
        (out / (name + ".stdout.txt")).write_text(stdout, encoding="utf-8")
        (out / (name + ".stderr.txt")).write_text(stderr, encoding="utf-8")
        ok = rc == 0
        if name in EXPECTED_GATE and ok:
            try:
                payload = json.loads(stdout)
                ok = (payload.get("required"), payload.get("depth")) == EXPECTED_GATE[name]
            except (json.JSONDecodeError, KeyError):
                ok = False
        all_pass &= ok
        report["commands"].append({
            "name": name, "argv": argv, "started_utc": start.isoformat(), "ended_utc": end.isoformat(),
            "return_code": rc, "expectation_passed": ok,
            "stdout_file": name + ".stdout.txt", "stderr_file": name + ".stderr.txt"
        })
        print(("PASS" if ok else "FAIL"), name, "exit", rc)
    report["status"] = "PASS" if all_pass else "FAIL"
    (out / "run_local_qa.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("Static QA summary:", report["status"], "(native test still required)")
    return 0 if all_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
