# DeskFern Studio | Synthetic business test input

**THIS BUSINESS DOES NOT EXIST.** Everything below is made up solely to test orchestration, CRO, claims and review holds. Do not reuse as commercial facts, real analytics, or actual client data.

## Fictional owner facts

- Brand: **DeskFern Studio**.
- Service: weekly in-person watering and brief indoor plant-health checks for professional offices.
- Target buyer: office managers overseeing around 8–30 plants.
- Geography: **Lakehaven**, a fictional metro area.
- Intended outcome: simplify responsibility for upkeep of existing office plants. No validated productivity, morale, savings, or plant-survival improvement is claimed.
- Planned sales: referrals plus a future inquiry form.
- Business state: **not launched**, no paying customers, no actual conversion page, no demand research, no testimonial evidence.
- Proposed operational capacity: six weekly visits. This is a synthetic assumption, not a verified capacity.
- Proposed pricing anchor: **$249/month**, not approved, not validated for profitability or customer willingness to pay.
- Cost inputs **unknown**: travel, labor time, insurance, materials, plant replacement, guarantees, payment processing, CAC, sales cost, and incidentals.
- Commercial rules **unknown and not approved**: billing, refunds, cancellation, contract term, eligibility, service exclusions, replacement guarantees, renewal, and scope changes.
- No independent reviewer has been supplied or authorized to be reported as having run. The test host may attempt a real separate context, but must record actual tool availability, execution or refusal.

## Limitations to declare

- `Fictional fixture; real business validation absent` is a protected historical obligation identity when applicable to the current intake.
- Refund/cancellation policies: unknown, hold before final commercial promise.
- Delivery and guarantee cost exposure: unknown, hold financial feasibility and approval claims.
- PITCH, HOOKS and LANDING_PAGE assets require separate-context review in a controlled run, or corresponding per-artifact holds plus one aggregate `[review] Independent review remains required.` blocker.
- Do not invent client counts, online reviews, endorsements, test results, cost savings, profit, time saved, email subscribers, actual SEO results or established performance.

## Separate intentionally defective HTML demo (Case D ONLY)

Case C, full offer, **has no live website**. Treat the local demo page as **a separate synthetic CRO inspection fixture for Case D**, never as real traffic evidence or a production site for the full offer.

The local page in `demo_landing.html` contains deliberate source-level issues. The fabricated analytics in `SYNTHETIC_ANALYTICS.csv` are for reasoning about data type and possible hypotheses. They cannot establish true causality, unique-user rates or conversion improvement.
