# Evidence collection, security, and first-completion immutability

Use a separate evidence directory **outside the repository and outside every case workspace**. For example:

```
pr5-deskfern-evidence/
  preflight.json
  local_qa/
  sessions/
    A/{SESSION_RECORD.md,first_reply.txt,host_observations.txt,first_completion.zip,first_completion_hashes.json}
    B/{...}
    C/{...,checker_ready_stdout.txt,checker_ready_stderr.txt,checker_exit_code.txt}
    D/{...,screenshots/390px.png,screenshots/1440px.png}
  TOKEN_LEDGER.csv
  ACCEPTANCE_MATRIX.csv
  INDEPENDENT_REVIEW.md
  FINAL_DECISION.md
```

There are **no run files in this packet**. The `evidence/empty/` folder is intentionally empty. It is forbidden to backfill fake runs or fabricated model metadata.

## Timing and integrity

1. At the start of each native chat, record source pin, host/client version, exact initial user prompt and inputs allowed.
2. When it finishes **the first time**, preserve the original answer and the first full workspace. Do not edit/correct outputs.
3. Run `scripts/capture_first_completion.py --workspace ... --out ...` immediately. It reads `workspace/output/`, zips it, hashes each file and writes manifest + snapshot outside workspace. The script rejects `--out` inside the workspace and skips unsafe symlinks.
4. Preserve host transcript/tool observation entries that are safe to export. Exclude hidden reasoning, private credentials or opaque model transport payloads.
5. Run the installed checker on untouched files, capture stdout/stderr and exit code, then let an independent reviewer examine outputs and the source fixture. Checker `HELD` is expected when no real separate reviewer exists.
6. Re-hash output tree after QA if needed and compare to frozen first-completion manifest. Any change is recorded as a test contamination, not hidden.

## Provenance

A reviewer must be able to answer: (a) Which exact SHA was installed? (b) Which SKILL.md and required references were actually loaded and when? (c) Did the host dispatch a real specialist or refuse and fall back? (d) Was the CRO method actually run without an explicit user request? (e) What separate-context review really occurred? (f) What business limitations were declared? (g) What changed after completion? (h) Were tokens observed or merely estimated?

If the host reports no input/output tokens, enter `unknown` in the ledger. Do not assume 0, invent an average, or promise a strict budget. Record elapsed wall time only from a real measurement or host log. This is important for the QUICK vs GUIDED vs DEEP comparison.

## Data minimization

Use only fictional workspaces. Do not place real business private files, customer email addresses or access tokens in the workspace being archived. The capture helper archives `output/`, **not the source checkout**, hidden model reasoning, browser passwords, or all contents of the user's home directory.

## Independent review

An independently executed analysis should compare outputs to `fixtures/FICTIONAL_BUSINESS.md`, `fixtures/SYNTHETIC_ANALYTICS.csv` and `docs/02_ACCEPTANCE_MATRIX.md`, examine the code/HTML for D, check exact load/dispatch evidence, and separately enumerate the seven obligation identities. If no truly separate review occurred, label the provenance limitation and leave existing review holds open. An AI-written checklist is not a cryptographically authenticated reviewer receipt.
