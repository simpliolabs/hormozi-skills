# Source pin and reproducibility

At preparation, the target was `simpliolabs/hormozi-skills` PR #5, head `6b7a04e949e4ed69019591acab9f616107348b7c`. PR #5 is stacked on PR #4's `docs/repo-onboarding-review-2026-11-05` branch, not directly on `main`.

GitHub links:
- PR #5: https://github.com/simpliolabs/hormozi-skills/pull/5
- Exact commit tree: https://github.com/simpliolabs/hormozi-skills/tree/6b7a04e949e4ed69019591acab9f616107348b7c
- Source CI: https://github.com/simpliolabs/hormozi-skills/actions/runs/42128049903
- Canonical tracked fixture directory: https://github.com/simpliolabs/hormozi-skills/tree/6b7a04e949e4ed69019591acab9f616107348b7c/docs/qa/pr5-fictional-business
- PR #3 validation evidence (historical, protected): https://github.com/simpliolabs/hormozi-skills/tree/main/docs/qa/business-validation-registration

**Run against the source checkout, not the files in this packet.** This packet includes portable fictional inputs, reference copy, source fingerprints, scripts, and acceptance rubrics. It intentionally does not vendor a full duplicate codebase: doing so could silently test an altered or stale copy. The preflight verifies source SHA and tracked Git blob IDs for the critical files. The development host must install source from this pinned checkout, not from whichever plugin version happens to be cached.

The portable local fixture files are functionally equivalent to the repo's test fixtures; use the **pinned tracked source copies** as the canonical evidence basis where exact byte identity matters. The blob fingerprint manifest contains Git's content IDs for those tracked files. `git rev-parse HEAD:<path>` is the authoritative byte identity; no guesswork from filenames.

If any new commit lands on PR #5, the developer must not silently change test SHA. Either run the pinned candidate above, or request a new explicit acceptance pin and refresh the packet/manifest.
