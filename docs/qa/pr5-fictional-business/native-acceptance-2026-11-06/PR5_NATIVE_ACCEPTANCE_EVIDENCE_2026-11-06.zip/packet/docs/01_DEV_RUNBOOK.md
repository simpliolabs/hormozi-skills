# Developer execution runbook

## 0. Safety and boundaries

The named business, customers, analytics, and landing page are all fabricated for acceptance testing. No real PII, payment collection, external messaging, web publishing, live conversion event, or production system action is permitted. This pack authorizes controlled testing and review **only**. No reviewer may certify a separate-context pass that did not actually happen.

The supplied `demo_landing.html` intentionally contains a delayed demo-only submit and a dubious claim. Keep it local. It is not production code and must not be published.

## 1. Source and host preflight

Use **exact** source SHA `6b7a04e949e4ed69019591acab9f616107348b7c`. The full repository is fetched from GitHub with developer credentials. Use `START_HERE.md` checkout commands. Do **not** test the default branch instead, or mix PR #4's branch with the PR #5 candidate. Run `scripts/preflight.py`; preserve JSON. It verifies Git HEAD, tracked worktree cleanliness, important file blob identities, and Python/platform metadata.

Record host and version, actual installed plugin/skills root, how selection occurs in that host, and whether true native subagent tools are available. Don't assume the names in `agents/` mean another context ran. If the host cannot load the source revision, mark `INCONCLUSIVE` with the exact blocker.

## 2. Local code and repo QA

Inside a Python 3.12 test environment, install requirements from source repo and run:

```
python -m unittest discover -s tests -v
python scripts/check_outputs.py --repo .
python scripts/cro_gate.py --stage A --surface planned
python scripts/cro_gate.py --stage B --surface live
python scripts/cro_gate.py --stage D --surface offline
python scripts/cro_gate.py --stage C --surface live --digital-destination
python scripts/cro_gate.py --stage E --surface live --focused
```

Use `scripts/run_local_qa.py` to capture actual commands, output and exit codes as JSON/text. A successful deterministic router demonstration proves only branch logic, not automatic AI method loading. Don't conflate these.

## 3. Native sessions (clean-room)

Perform the four cases in `docs/03_NATIVE_SESSIONS.md`, with prompts from `fixtures/prompts/` unchanged. Use a **new conversation and empty workspace per case**. A/B/C must be independent of earlier case content. Session C must never receive a user prompt containing the token `CRO`, `conversion optimization`, or the name `cro-page-optimizer`, because the purpose is to verify implicit downstream routing. The developer can observe those terms in internal skill guidance or outputs, but not seed them in the user's request.

Do not show the intended success rubric, case letter or expected route inside the user's native chat. Keep fixtures available as **read-only business data** only where instructed. This avoids giving the model an answer key.

For beginner case A, record the **first assistant reply before providing any business facts**. Only then send scripted reply A2. It is acceptable to pause at the first valid checkpoint and record unfinished work. Do not misclassify such a limited pilot as end-to-end acceptance.

Session B must not be warmed up with any previous orchestration instructions. Session D receives the local HTML and synthetic analytics only; if visual browser tools are unavailable, record `NOT ASSESSED` for actual screenshot QA, but source code defects may still be reviewed.

## 4. Freeze first completion before review

Immediately after each native first completion, run `scripts/capture_first_completion.py` with the correct workspace and an evidence destination **outside the source checkout and workspaces**. Never modify authored artifacts or their hashes first. Capture the original assistant response from the host and preserve native tool/dispatch receipts and token usage only if the host exposes them. Reviewer actions belong after capture and in separate files, not edits to first-completion.

Session C should contain `output/CRO_REVIEW.md`, canonical `output/SUMMARY.md` with its exact four level-two headings, and coherent `RUN_STATE`, `CHECKPOINT`, `QA_REPORT`. If missing, do not synthesize these by hand. Record a FAIL/INCONCLUSIVE based on cause.

Run the installed read-only checker on the untouched workspace. A `HELD` status is the correct outcome when seven obligation identities remain unresolved; `READY` in that situation is suspicious. Record every checker finding and independently audit the business and review holds.

## 5. Evidence and independent reviewer

The operator sends the frozen first-completion artifacts, raw prompt text, exact source pin, host logs, checker outputs and filled worksheets to a **separate reviewer context**, if available. The independent reviewer must identify whether a genuine separate-context review occurred, which claims were actually supported, and whether all relevant holds persist. If no isolated review is possible, say so. Do not mint `context: separate` metadata to simulate it.

For each scenario: `PASS`, `FAIL` or `INCONCLUSIVE` with a 1-2 sentence grounded reason, evidence file path, and source SHA. For native method loading, screenshots and token counts, explicitly use `unknown` or `not observed` when unavailable. Never mark zero tokens based on missing usage telemetry.

## 6. Merge/release decision

Passing source CI alone does not clear the native gate. Even a PASS of this fictional test is limited to a bounded synthetic run. A native PASS allows a **new PO review for PR #5**, not immediate deployment, publication, release, or waiver of held business terms. Keep PR #4's stacked-base relationship visible and recheck CI after any rebase or code change. See `docs/05_RELEASE_DECISION.md`.
