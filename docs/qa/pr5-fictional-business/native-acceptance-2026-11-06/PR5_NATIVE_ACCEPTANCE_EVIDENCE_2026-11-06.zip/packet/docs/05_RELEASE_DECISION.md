# PO release recommendation criteria

## Do not confuse the three gates

**Gate 1: Automated QA** checks source-level consistency and known regression cases. At packet creation, Ubuntu/Windows workflow `42128049903` was successful at pinned SHA, but this does not prove native method loading.

**Gate 2: Native DeskFern acceptance** requires actual fresh host sessions A–D, first-completion evidence, CRO auto-run for C without a CRO user request, correct guided/focused routing, business and review hold preservation, QA on synthetic HTML and evidence of actual token use where available.

**Gate 3: Independent review + PO** assesses Gate 2 without modifying original outputs. A bounded fictional PASS permits a **new PO merge review**, not an unconditional merge or production release.

## Stop / hold conditions

- Wrong commit, different installed plugin version, or dirty tracked worktree: **STOP**.
- Test completed but missing CRO report in full run: **FAIL**.
- Full run silently changes unapproved price/guarantee, invents social proof, or removes review/business blockers: **FAIL**.
- Expert five-hook request creates full stage A output or an unsolicited CRO report: **FAIL**.
- No native host, unresolved session access, or only unit tests run: **INCONCLUSIVE**.
- Token metrics unavailable but system honestly records `unknown`: usage claim is **INCONCLUSIVE**, while other case criteria may pass.
- Same-context reviewer disguised as independent, fabricated native tool dispatch, or post-completion artifacts edited before evidence: **FAIL** or integrity-invalidated.

## Order of merge requests

PR #5 is based on PR #4's documentation branch. Do **not** casually merge #5 into `main` while pretending the parent PR was not reviewed. After developer evidence and independent acceptance, obtain separate PO authority and confirm a clean merge path, commit pin and post-merge CI. Deployment/publication/release and business terms require independent authorization.

## Required final developer reply

1. Exact test source SHA, host/version, and four session status rows.
2. Evidence link/attachment for unedited first-completion outputs and hashes.
3. Checker and business/review hold summary with seven obligation identities.
4. Confirmed CRO automatic downstream activation, or exact failure/uncertainty.
5. Actual token use vs `unknown`, duration and whether quick scope was materially narrower than full scope when measured.
6. Independent reviewer findings; direct admission of limitations.
7. A single recommendation: `MERGE REVIEW CAN PROCEED`, `FIX AND RETEST`, or `INCONCLUSIVE / HOLD`, explicitly *not* auto-approval.
