# Acceptance gates and scoring rules

**Result vocabulary**

- `PASS`: Direct evidence from the first native completion or independent inspection satisfies the stated criterion.
- `FAIL`: Direct evidence contradicts the criterion or a required output is absent despite a completed opportunity.
- `INCONCLUSIVE`: Host cannot load/observe the behavior, runtime evidence is absent, run was interrupted, or no independent reviewer executed; clearly state the missing evidence.
- `NOT_RUN`: Not attempted. Never count as a pass.

The detailed 32-row checklist is in `templates/ACCEPTANCE_MATRIX.csv`. Keep every row and fill actual status, evidence path and notes. Do not prefill the acceptance results.

## Hard gates

1. Exact candidate pin and clean source; correct installed skill root (source Git revision proved).
2. Beginner first response contains at most one real question and ordinary-language route; verify auto discovery or explicitly mark the discovery claim unproven.
3. Expert case returns exactly five hooks and does not create the full run state, including no CRO report.
4. Full-offer case uses only selected methods, root owns business decisions, includes downstream CRO readiness *without user asking for it*, and preserves the no-real-page limitation.
5. Existing seven hold identities protected: three business obligations (absent real validation, refund/cancellation unknown, unknown cost economics) plus three sales-artifact review requirements (PITCH/HOOKS/LANDING_PAGE) plus run-level independent-review blocker. Refund and unknown cost may legitimately be combined in one checker finding.
6. Canonical SUMMARY has `## Offer`, `## Key Decisions`, `## Best Hook`, and `## Next Actions` with three prioritized numbered items. Best Hook must contain the chosen hook text.
7. Direct CRO case distinguishes actual local HTML defects and fixture-generated aggregate session counts from measured causes; recommends baseline repairs before optional A/B hypotheses.
8. First-completion artifacts are hash-preserved before any manual edits; checker is executed read-only; results are independently assessed where real reviewer execution is available.
9. No claims of authenticated separate-context execution or native differentiated specialists unless actual tool/session evidence exists.
10. Current-head Windows and Ubuntu CI green; no runtime or artifact repair after first completion; no publish/merge action.

## Decision matrix

| Evidence | Acceptable result |
| --- | --- |
| Synthetic data not real | `HELD` business-validation marker persists |
| Sales copy review not actually delegated | Sales-artifact holds and aggregate review blocker persist |
| API does not expose tokens | `unknown` in ledger; no invented number or 10M-token claim |
| No live page in full offer | CRO *readiness* with page-level checks `NOT ASSESSED` |
| Local HTML only in CRO case | Code issues may be confirmed; browser rendering only claimed if tested |
| Host refuses specialist dispatch | Record exact refusal; sequential fallback truthful; differentiate from genuine delegation |
| Relevant hold still open | Provisionally useful draft may be delivered, but never approved for public commercial use |
| Good unit tests, native test missing | **INCONCLUSIVE**, retain draft |

## Scope of independent semantic review

A different context must inspect original source facts, final claims, exact selected method loads, CRO report content, summary, authorizations and all holds. Their opinion must be independently recorded in `templates/INDEPENDENT_REVIEW.md` without editing original run artifacts. Static check passing proves structure, not full factual validity or actual specialist execution.
