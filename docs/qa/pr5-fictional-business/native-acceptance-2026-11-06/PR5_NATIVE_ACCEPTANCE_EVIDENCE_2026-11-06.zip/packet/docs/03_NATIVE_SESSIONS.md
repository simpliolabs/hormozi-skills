# Four native sessions: exactly how to test

**Prerequisite:** Fresh checkout at pinned SHA and a real supported Claude Code or Codex host with the source candidate installed. For every case use a different, clean chat/context and empty project workspace. Inspect actual host behavior; reading or repeating this test script in a normal chat is not a native runtime test.

## Case A: GUIDED BEGINNER (no skill name, no business context)

First message is **exactly** `fixtures/prompts/A1_BEGINNER.txt`:

> I have a business idea but no idea what to ask. Can you guide me?

**Before any scripted follow-up:** preserve the *very first* assistant message, native skill-selection trace if available, observed skill reads and question count. Desired: brief explanation plus just **one** high-value question. No long form, no all-skill preloading, no imaginary market validation. Note whether automatic host discovery actually selected the orchestrator. If it did not, mark automatic-discovery outcome `FAIL` or `INCONCLUSIVE` as evidence warrants; an explicit second try must be recorded separately.

Then only after first response use `fixtures/prompts/A2_OWNER_FACTS.txt`:

> I want to start DeskFern Studio, a weekly indoor plant-care service for small offices. I know the basic service but not the pricing, cancellations, costs, or marketing. I don't have a website or customers yet. Please guide me; no publishing.

Expected subsequent guided path: identify the appropriate Stage A-like work, record missing inputs without inventing them, plan selected methods and **eventual CRO readiness** downstream, not full speculative site analysis. This case can stop at the first valid checkpoint if it was scoped only to the guided entry. Do not label a partial entry as a full end-to-end pass.

## Case B: PRECISE EXPERT (hooks only)

Use `fixtures/prompts/B_EXPERT_HOOKS.txt` exactly, in a fresh chat:

> I want exactly FIVE Instagram hooks for DeskFern Studio. It provides weekly watering and plant-health checks for small offices with 8–30 indoor plants. These details are synthetic test inputs. Do not claim results, time saved, productivity gains, customer reviews, prices, or guarantees. No wider offer-building work.

Expected: **exactly five** usable synthetic hooks. Load only the matching hooks method; no full offer run records, no other specialist task, and **no** CRO_REVIEW file. Do not call hooks proven or tested. Record actual token telemetry if available, not guessed.

## Case C: FULL OFFER, **automatic CRO** despite NO request for it

Give the business facts from `fixtures/FICTIONAL_BUSINESS.md` as read-only source data in the fresh test workspace (the canonical repo copy lives under `docs/qa/pr5-fictional-business/BUSINESS_FIXTURE.md`). Paste the exact `fixtures/prompts/C_FULL_OFFER_NO_CRO_WORD.txt` message:

> Build the complete DeskFern Studio offer and its sales assets: market and audience reasoning where needed, offer, value explanation, pricing feasibility, pitch, five hooks, and a landing-page draft. Use only the attached fictional business facts. Mark unknown costs, cancellation/refund terms, unsupported claims and absent real-world validation. Do not publish or fabricate independent reviews. Return a clear summary with three owner actions.

**Negative-control rule:** the user prompt must not mention CRO, post-click optimization, `cro-page-optimizer`, or the gate. Do not supply the rubric or expected artifact names in the native user message. Expected first completion should demonstrate:

- Stage A selective dependencies. Record exact methods and references **actually loaded** (not inferred from role labels), requested/observed models, actual native dispatch or refusal and any sequential fallback.
- Pricing ($249/month is a proposal only), costs, refunds, cancellation, and other commercial terms are unresolved unless genuine separate owner approval occurred. No fake claims of customer count, validated demand, financial returns, performance uplift or testimonials.
- Default downstream **CRO readiness** runs when selected offer/sales drafts exist, owned by root, with `output/CRO_REVIEW.md` before final SUMMARY and checker. Since this fictional offer has no live page, it must say page-specific visuals, Clarity data, form rates, SEO performance are `NOT ASSESSED` and must **not** pretend the local demo is already live.
- Canonical `SUMMARY.md` has `## Offer`, `## Key Decisions`, `## Best Hook`, `## Next Actions` and exactly three numbered real next actions.
- Record all seven obligation identities from `docs/02_ACCEPTANCE_MATRIX.md` as appropriate, even if multiple obligations share one finding. Do not alter any original historical evidence or create `context: separate` reviewer metadata if a separate review was not done.
- `RUN_STATE`, `CHECKPOINT`, `QA_REPORT`, manifest, decisions and claims are coherent. If anything is held, chat must label it `HELD`, while still returning a useful provisional offer.

**Important:** If this case is not actually a full, native execution, do **not** mark auto-CRO PASS simply because the static routing helper says it would run.

## Case D: DIRECT CRO (source + simulated events)

In another fresh chat, present `fixtures/demo_landing.html` as a local **fictional** source file and `fixtures/SYNTHETIC_ANALYTICS.csv` as fabricated test events. Use `fixtures/prompts/D_DIRECT_CRO.txt` exactly:

> Review this local DeskFern Studio demo page and the supplied synthetic interaction summary. Identify the first barrier to inquiry completion. Separate confirmed fixture defects from design hypotheses. Propose the exact shared-baseline repair and, only if appropriate, a separate A/B test. Do not claim any observed real customers or live conversion improvements.

Expected findings:

1. 1040px fixed `.shell` at 390px causes horizontal overflow (source-evident; if browser is available reproduce visually at 390px and also check desktop).
2. 9.5-second delayed submit with no pending indicator or duplicate prevention (source-evident client-side behavior).
3. Header offers sign-in to prospects even though the fictional business has no member accounts (UX issue grounded in fixture; effect on conversion **not proven**).
4. “Trusted by 5,000+ companies” is unsupported and **must be held or removed**, not reused as proof.
5. Analytics are **fictional aggregate sessions**. Do not confuse sessions with unique users; the counts do not prove causal abandonment reasons.
6. **FIX** confirmed technical/claim failures in a shared baseline. Only **TEST** an unproven headline/CTA change as a separate hypothesis with denominator, assignment and QA safeguards.

If rendered visual checks cannot be performed, mark actual viewport QA `NOT ASSESSED` (do not claim screenshots exist). No real WordPress, backend, web hosting or external links are involved.

## Integrity rules for all cases

Before moving to the next case, save the first response, source SHA, raw outputs, output hashes, checker result and actual tool metadata in a separate evidence location. A test after manual edits is a **second run**, not repaired first completion. Any material claim changed downstream invalidates dependent artifacts and review receipts. Keep all publication/deployment/commercial release holds intact.
