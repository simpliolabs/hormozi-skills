# Five draft hooks
Fictional creative copy, not testimonials or validated claims. Audience throughout: solo fractional-operations consultants in the US with an existing offer and at least three past paying clients. Objective: articulate an existing offer; no business outcome is promised. Any use below is a suggestion only; nothing sent or published.

1. Your operations expertise, explained in a one-page offer brief.
2. Solo fractional-operations consultants: put your existing offer into words you can work from.
3. Hard to explain what clients buy from you? Start with a focused offer brief.
4. One offer brief. Five draft hooks. One landing-page outline.
5. Bring your existing offer to a 90-minute working session focused on how you explain it.

## Selection and use
Best: hook 1, for its concrete artifact and audience relevance; editorial choice, not tested performance. Hook 2 suits audience-specific organic copy; hook 3 a problem-led email draft; hook 4 a page section; hook 5 a process explanation. Do not remove the eligibility qualification when using these drafts. Complete timing and commercial terms belong alongside any sales use. No additional hook variants generated.
