# Pitch ? pass 2 offer v1
Local synthetic-fixture draft, decision version 1. No sends or publication.

## Short pitch
Own a 1-5 person design studio? Give your next client kickoff agenda a focused working session. A draft agenda during the workshop is the intended first result, not a guaranteed outcome. USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Draft CTA: Request workshop availability.

## Medium pitch
Work on your next client kickoff agenda with FixtureWorks' Client Kickoff Workshop for owners of 1-5 person design studios. The workshop provides dedicated working time, the checklist supplies a reference, and email support gives you a channel for questions for seven days. A draft kickoff agenda during the workshop is the intended first result; completion is not guaranteed. USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Draft CTA: Request workshop availability.

## Long pitch
If planning what belongs in a kickoff agenda feels unclear, give the draft a dedicated working session. FixtureWorks' Client Kickoff Workshop is for owners of 1-5 person design studios. The intended first result is a draft kickoff agenda during the workshop; it is not a promise of a finished implementation, new clients or increased revenue.
The workshop is working time for your agenda. The kickoff checklist is a reference. Seven days async email support provides a channel for questions afterward. USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Your participation is required. Preparation requirements and email response time are unspecified. Capacity is two sessions/week; there is no deadline/promotion and remaining availability is unknown. No extra follow-up session or inflated value anchor is included.
Draft CTA: Request workshop availability. No active booking destination was supplied.

## Value Equation and positioning notes
Dream outcome: agenda draft instead of broad growth. Likelihood: a concrete mechanism, with no outcome proof invented. Delay: intended work during the 90-minute session; booking timing unknown. Effort: participant work remains required, with checklist and bounded support. These are copy improvements, not measured conversion gains.
Name options, editorial only: Client Kickoff Workshop; Design Studio Kickoff Workshop; Kickoff Agenda Workshop; Small Studio Kickoff Session; Kickoff Agenda Working Session. Retain the existing Client Kickoff Workshop name.
No bonuses or component dollar valuations. The supplied cancellation refund is the only authorized refund wording used; alternative guarantees are excluded.

## Objection responses
**Is this worth USD250?** The fee buys the stated workshop, checklist and support; financial ROI is unverified.
**Does it guarantee clients?** No outcome guarantee.
**How much time is involved?** One 90-minute workshop; preparation and later application effort are unspecified.
**Can I cancel?** Full refund if cancelled at least 24 hours before workshop. Other refund/rescheduling treatment unknown.
**How fast will emails be answered?** Support is async; no response time is promised.
