# FixtureWorks ? landing-page copy draft
Synthetic fixture, offer v1; no page built or published. Outline: hero, problem, outcome, solution/mechanism, value stack, proof, objections/refund, CTA, FAQ.

## Hero
### Work on your next client kickoff agenda in 90 minutes
For owners of 1-5 person design studios. A focused Client Kickoff Workshop, with a draft kickoff agenda as the intended first result during the workshop. Completion is not guaranteed.
USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Draft button: Request workshop availability.

## Problem
Not sure what belongs in your next kickoff agenda? A dedicated working session gives you time to focus on the draft. This is a proposed buyer situation, not a claim from customer research.

## Outcome
The intended first result is a draft kickoff agenda during the workshop. Your participation is required; no client, revenue, time-savings or completed-implementation result is promised.

## Solution and mechanism
Work on the agenda during the workshop, use a kickoff checklist as a reference, and ask questions through seven days async email support. The mechanism is a bounded working session with supporting materials; it is not a proven proprietary system.

## What is included
- One 90-minute workshop: dedicated time to work on the draft.
- One kickoff checklist: a reference for planning the kickoff.
- Seven days async email support: a channel for questions afterward.
USD 250 one time. No bonus or separate standalone value comparison is asserted.
Draft button: Request workshop availability.

## Proof
No testimonials, interviews, case studies, customer outcomes or external market evidence are available. Editorial hold: obtain genuine evidence before adding proof; omit this placeholder from any future public version. The described process explains delivery, not demonstrated success.

## Fit, effort and refund
For owners of 1-5 person design studios who want a focused session to work on a kickoff agenda. Expect to participate and apply your work afterward; preparation requirements are unknown.
Full refund if cancelled at least 24 hours before workshop. No outcome guarantee. Other refund and rescheduling terms are unspecified; this statement does not establish their exclusion.

## Final invitation
Work on your next kickoff agenda with a defined workshop, checklist and email support.
USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Draft button: Request workshop availability.
Capacity: two sessions/week; no deadline/promotion. This does not state remaining availability.

## FAQ
**Will I leave with a finished agenda?** A draft during the workshop is the intended first result; completion is not guaranteed.
**Will this bring clients or revenue?** No outcome guarantee; neither result is promised.
**Is there a follow-up call?** The authorized scope is one 90-minute workshop, one checklist and seven days async email support; no extra call is included.
**Is support instant?** It is async email; response times are unspecified.
**What if I cancel?** Full refund if cancelled at least 24 hours before workshop. Other refund treatment unknown.
**Can I book now?** This is local draft copy; no booking link or live availability was provided.
