# Pitch ? local draft, offer v1
Synthetic fixture. Structure: audience, intended result, mechanism, components, price, qualified refund, draft CTA.

## Short version
Own a 1-5 person design studio? Work on your next client kickoff agenda in a focused workshop. USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Intended first result: draft kickoff agenda during workshop. Draft CTA: Request workshop availability.

## Medium version
Give your next client kickoff agenda a dedicated working session. FixtureWorks' Client Kickoff Workshop is for owners of 1-5 person design studios, with a draft kickoff agenda as the intended first result during the workshop. USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
You'll participate in the working session and can use the checklist and email support to help with questions. No client or revenue outcome is promised. Draft CTA: Request workshop availability.

## Long version
If deciding what belongs in your next client kickoff feels difficult, set aside a focused session to work on the agenda. FixtureWorks' Client Kickoff Workshop is for owners of 1-5 person design studios. The intended first result is a draft kickoff agenda during the workshop; completion is not guaranteed.
The workshop gives you dedicated working time; the kickoff checklist gives you a reference; async email support provides a channel for questions for seven days. USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
There are no added bonuses or invented standalone dollar values. Capacity is two sessions/week, with no deadline or promotion; remaining availability is unknown. This is a workshop requiring your participation. It does not promise new clients, revenue or a completed implementation. Draft CTA: Request workshop availability.

## Value Equation and copy controls
Dream outcome: an agenda draft rather than broad agency growth. Likelihood: understandable delivery mechanism, with no invented proof. Delay: intended draft during the session, with unknown booking lead time. Effort: live participation and later application still required. No measured improvement claimed.
Name options (editorial only): Client Kickoff Workshop; Design Studio Kickoff Workshop; Kickoff Agenda Workshop; Small Studio Kickoff Session; Client Kickoff Working Session. Existing name retained in this draft.
No outcome, unconditional or extended-support guarantee is authorized; only the stated cancellation refund is used. No scarcity beyond supplied capacity; no testimonial, case study or market evidence.
Objections: Time? One 90-minute workshop; preparation unknown. Worth it? USD250 buys the listed scope; buyer ROI unknown. Guaranteed clients? No outcome guarantee. Cancellation? Full refund if cancelled at least 24 hours before workshop; other refund treatment unknown. Async support response time is unspecified.
