# FixtureWorks Client Kickoff Workshop ? offer v1
Local draft; synthetic fixture. Commercial decision version 1; authority: input/owner_terms.md.

## Business snapshot and audience
For owners of 1-5 person design studios. Existing offer reported as not converting; channel, baseline rate, demand and buyer urgency unknown. The working problem hypothesis is difficulty turning kickoff intentions into an agenda; no customer interviews substantiate it.

## Directions considered within existing scope
1. Agenda-first: emphasize drafting a kickoff agenda during the workshop. Recommended because it matches the owner-authorized first result.
2. Checklist-first: emphasize the existing checklist as a guide; simpler but risks hiding the workshop's main result.
3. Support-first: emphasize seven days async email support; useful reassurance but too vague as the main reason to buy.
These are editorial angles, not changed packages or validated demand. Choose agenda-first provisionally for this draft.

## Outcome and positioning
Work on your next client kickoff agenda in a focused 90-minute workshop.
The intended first result is a draft kickoff agenda during the workshop; completion and subsequent results are not guaranteed. A clearer next step is a proposed emotional benefit, not a measured outcome. Client acquisition, revenue growth, time saved and reduced scope creep are unverified and excluded from promises.

## Obstacle-to-solution map
All obstacles below are hypotheses for validation, not interview findings; solution examples are proposed uses within the existing workshop, not extra deliverables.
| Potential obstacle | Existing component / proposed application |
| --- | --- |
| Unsure where to start | Workshop: begin an agenda draft |
| Unclear kickoff purpose | Workshop: discuss intended meeting purpose |
| Unsure which topics belong | Checklist: guide topic selection |
| Difficulty ordering topics | Workshop: work through agenda order |
| Missing questions | Checklist: review possible gaps |
| Too much material | Workshop: prioritize discussion topics |
| Hard to translate ideas into writing | Workshop: work on the draft together |
| Unclear next steps | Workshop: consider next-step agenda items |
| Uncertainty applying checklist | Seven days async email support |
| Questions after workshop | Seven days async email support |
| Unclear scope of purchase | Explicit component list below |
| Worry about cancellation | Stated cancellation refund condition |
Customer participation is required; preparation requirements, email response time and later implementation effort remain unspecified.

## Core offer and value stack
USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
- Workshop: a defined session in which to work on a kickoff agenda draft.
- Kickoff checklist: a reference for thinking through the kickoff.
- Async email support: a channel for questions over seven days; no instant-response promise.
Standalone dollar values and total stacked monetary value are unknown; no inflated comparison anchor. No bonuses, onboarding charge, additional session, subscription or upsell is included. Bonus-stack task: not_requested.
Capacity: two sessions/week; no deadline/promotion. Capacity is not evidence of remaining availability.

## Refund and guarantee
Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Unconditional, outcome-based and extended-support guarantees are not authorized; none is recommended for inclusion. Later-cancellation, rescheduling and other refund treatment are unknown; do not infer that all other refunds are excluded.

## Messaging
Hooks: Work on your next kickoff agenda in 90 minutes. / A focused kickoff workshop for small design studios. / Give your kickoff agenda a dedicated working session.
Outcome bullets: focus on a draft agenda; use a kickoff checklist; ask followup questions by async email for seven days. These describe intended use, not assured completion.
Objections: participant work is required; client or revenue outcomes are not promised; the purchase is a bounded workshop with checklist and support.
Draft CTA: Request workshop availability. This is suggested copy with no active booking destination.

## Unapproved proposals ? excluded
Value's 30-minute follow-up bonus; Pricing's USD299 plus onboarding charge; Sales' unconditional 90-day refund. None has owner acceptance; all remain excluded from offer v1 and sales copy.

## Validation and holds
Before any spending, test whether target buyers can restate the outcome, scope, price and refund condition. Record real objections and the existing conversion baseline. Obtain evidence of buyer urgency and willingness to pay; do not infer either. Channel and proof remain unknown. No publication is authorized.
