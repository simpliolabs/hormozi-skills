# Landing-page copy ? pass 2 offer v1
Local synthetic-fixture draft; no page built or published. Outline: hero, problem, outcome, solution, mechanism, value stack, proof, objections, refund, CTA and FAQ.

## Hero
### Give your next client kickoff agenda a focused working session
FixtureWorks' Client Kickoff Workshop is for owners of 1-5 person design studios. A draft kickoff agenda during the workshop is the intended first result; completion is not guaranteed.
USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Draft button: Request workshop availability.

## Problem
If you're unsure what belongs in your next client kickoff agenda, a dedicated session gives you time to work on it. This is a proposed buyer situation, not a customer-research finding.

## Intended outcome
Work on a draft kickoff agenda during the workshop. Your participation is required; no completed implementation, time savings, clients or revenue are promised.

## Solution and mechanism
A focused workshop gives you dedicated working time. The kickoff checklist is a reference for planning. Seven days async email support provides a channel for questions. This describes the authorized format; no proprietary or proven-success claim is made.

## What is included
- One 90-minute workshop to work on your agenda draft.
- One kickoff checklist to use as a reference.
- Seven days async email support for questions.
USD 250 one time. No extra follow-up call, bonus or made-up standalone dollar value is included.
Draft button: Request workshop availability.

## Proof ? editorial hold
No interviews, testimonials, case studies, customer outcomes or external market evidence are available. Obtain real evidence before adding proof. This placeholder is for the owner and is not proof or ready-to-publish copy.

## Fit, effort and refund
For owners of 1-5 person design studios. Participate in the workshop and apply the work afterward; preparation and email response timing are unspecified.
Full refund if cancelled at least 24 hours before workshop. No outcome guarantee. Other refund and rescheduling treatment is unknown; the stated condition does not establish exclusions.

## Invitation
Work on your next kickoff agenda with a bounded workshop, checklist and email support.
USD 250 one time. One 90-minute workshop; one kickoff checklist; seven days async email support. Full refund if cancelled at least 24 hours before workshop. No outcome guarantee.
Draft button: Request workshop availability.
Capacity two sessions/week; no deadline/promotion. Remaining availability is unknown.

## FAQ
**Will my agenda be finished?** A draft during the workshop is the intended first result; completion is not guaranteed.
**Will I get clients or revenue?** No outcome guarantee; neither is promised.
**Do I get another call?** Only one 90-minute workshop is included, plus the checklist and seven days async email support.
**Is email support instant?** It is async; response timing is unspecified.
**What if I cancel?** Full refund if cancelled at least 24 hours before workshop. Other refund treatment unknown.
**Is booking active?** This is local draft copy, with no supplied booking destination.
