from run_tools import *

def deliver(task,docs):
 prepare(task)
 for name,body in docs.items(): (ROOT/'output'/name).write_text(body.strip()+'\n',encoding='utf-8')
 accept(task,'Accepted '+task+' after frozen-input verification; next stage follows the B route.')

label='Fictional fixture draft only. Terms from input/owner_terms.md; no real business approval or outcome evidence.'
terms='''USD 750, one-time. Scope: one 90-minute working session, one-page offer brief, five draft hooks, one landing-page outline, and one asynchronous feedback round within seven calendar days. Draft deliverables arrive within five business days after complete intake.

No client/revenue/credit/funding/conversion outcomes are guaranteed. Refund and cancellation policy remain undecided: HOLD. No credit repair, bureau reporting, loan placement or business filing services are included.'''
audience='US solo fractional-operations consultants who already have an offer and at least three past paying clients'
position='Turn your existing fractional-operations offer into a one-page brief and draft messaging you can review and test.'

deliver('diagnostic',{'ORIGINAL_OFFER_AUDIT.md':f'''# Original Offer Audit

{label}

## Frozen original and diagnosis
Input: input/existing_offer.md only; original is preserved. Existing offer: a USD 750 one-time, 90-minute session with an offer brief, five hooks, a landing-page outline and one asynchronous feedback round. It says it helps consultants grow with an irresistible offer. Diagnosis only; no replacement copy or new terms here.

## Value Equation
| Dimension | Finding | Severity | Direction for revision |
|---|---|---|---|
| Dream outcome | Growth is unspecified and outside the stated deliverables | High | Describe a tangible offer brief and messaging |
| Perceived likelihood | No traffic, conversion or revenue results supplied | High | Explain the process; do not substitute claims for proof |
| Time delay | Session length is clear; delivery and support timing absent from original | Medium | Reconcile against the owner's authority |
| Effort and sacrifice | Session is bounded; preparation and feedback workload unspecified | Medium | Explain required participation without inventing effort estimates |

Numerical scores: unknown; no measurement or calibrated scoring basis supplied.

## Market, structure, value, price and objections
Audience is broad in this document. Buyer urgency, demand, affordability and failed alternatives are unknown. Structure is relatively simple; no evidence justifies additional components or bonuses. Standalone component values, market comparisons and ROI are unknown. USD 750 is stated, but this original alone supplies no cost basis. Price resistance cannot be diagnosed from absent conversion data.

Likely objections (inferred, not customer quotations): what will I receive, who is this for, how much work is required, and what happens if I cancel? Refund policy and economics cannot be inferred from silence.

## Priorities
1. Reconcile eligibility, scope, timing and policy with owner authority before rewriting.
2. Replace abstract growth language with deliverable-specific positioning.
3. Show the bounded process and test buyer comprehension; do not claim improved conversion.
'''})

deliver('revision',{'OFFER.md':f'''# CEO Creative Offer Clarity Sprint — revised offer v1

{label}

## 1. Business Snapshot
Existing fictional service; revision improves positioning only. Main channel unknown. No market research requested or performed.

## 2. Target Market
{audience}. Eligibility is owner-selected in the fixture; urgency, willingness to pay and reachability remain unvalidated.

## 3. Ideal Customer Avatar
An eligible solo consultant with an existing service to explain. Pain hypothesis: the current description feels vague. Specific failed attempts, emotional states and purchase triggers are unknown.

## 4. Dream Outcome
{position} Intended emotional benefit: more confidence explaining the offer (hypothesis). Status or financial improvements are unknown.

## 5–6. Obstacles and Solution Map
These ten obstacles are editorial hypotheses, not researched customer findings. Each maps to existing scope only.

| Possible obstacle | Existing component and proposed use |
|---|---|
| Audience description is broad | Working session: identify intended buyer |
| Problem sounds generic | Working session: state one concrete problem |
| Outcome is abstract | Brief: describe intended practical outcome |
| Scope is hard to explain | Brief: list inclusions |
| Boundaries are unclear | Brief: state exclusions |
| Process is unclear | Brief: summarize session and drafts |
| Opening message is weak | Five draft hooks: explore openings |
| Page has no structure | Landing-page outline: order sections |
| Draft wording needs refinement | One asynchronous feedback round |
| Claims exceed evidence | Working session and brief: separate aims from proof |

## 7. Core Offer
CEO Creative Offer Clarity Sprint. A working session plus prepared drafts; no new service vehicle or deliverable is added.

{terms}

Timing starts after complete intake, not purchase. The seven-calendar-day feedback term is preserved; its start event is not defined in the fixture and needs clarification before real use. Intake requirements and client preparation time are unknown. The process terms describe draft delivery, not a deadline for business outcomes.

## 8. Bonus Stack
Not requested; no bonuses or additional coaching calls.

## 9. Value Stack
Session: focused discussion; brief: concise reference; hooks: openings to test; outline: page structure; feedback round: bounded refinement. Component standalone values and total monetary value are unknown. No invented crossed-out anchor or ROI. Fixed fixture price: USD 750, one-time.

## 10. Guarantee
No outcome guarantees. Refund/cancellation remain HOLD; no money-back, nonrefundable or unlimited-support wording is adopted. Alternative guarantees intentionally not designed because terms are fixed.

## 11. Positioning
{position}

Three editorial directions considered within the same audience/scope: clarity-first (selected; closest to tangible work), message-consistency (secondary; requires testing), and page-preparation (secondary; risks making the outline sound like a built page). Selection is the writer's provisional editorial judgment, not a new owner approval. Differentiation is specificity and bounded work; superiority over competing services is unproven.

## 12. Messaging
Benefits to test: a concise offer reference; five openings to compare; a page outline to develop. Hooks are centralized in HOOKS.md to retain exactly five. Proposed CTA: Review the sprint details. No working booking or checkout is implied.

## 13. Validation Notes
Check comprehension with eligible readers before spending on promotion. Keep refund policy, acquisition cost, overhead, taxes and refund costs held. Validate actual total delivery hours against the 3.5-hour operating assumption. Capacity is an internal two-project weekly ceiling, never available inventory.
'''})

deliver('revised_check',{'REVISED_OFFER_CHECK.md':f'''# Revised Offer Check

{label}

Input offer: output/OFFER.md v1, decision v1. Method: audit-offer, reapplied to the revision.

| Dimension | Revised finding | Evidence limit |
|---|---|---|
| Dream outcome | Concrete brief and draft messaging replace vague growth language | Buyer desirability unknown |
| Perceived likelihood | Process and exclusions are inspectable | No real outcome evidence |
| Time delay | Five business days after complete intake preserved | Not a business-result deadline |
| Effort and sacrifice | One session and one feedback round are bounded | Intake effort and feedback-window start unknown |

Numerical scores remain unknown. Eligibility, price, scope and timing match owner_terms.md. No scope expansion, bonus, fabricated anchor, guarantee or scarcity is accepted. Market fit and affordability remain unknown. The internal mock ratings cannot establish real client outcomes or a success rate.

Editorial pass: wording is more specific. Commercial readiness held: refund/cancellation undecided; full economics and real validation absent. Proposed fixes are to resolve policies and test comprehension, not increase scope. Revised copy cannot yet be called proven to convert.
'''})

deliver('pricing',{'PRICING.md':f'''# Pricing and Economics — final feasibility on offer v1

{label}

Inputs: OFFER.md v1; REVISED_OFFER_CHECK.md; costs_and_feedback.md; owner_terms.md. Bonus work: not_requested. Decision v1. No scope or guarantee changes follow this pass.

## Buyer value and strategy
Fixed price: USD 750, one-time. Focused joint work with prepared drafts. The buyer receives a usable reference and starting copy; willingness to pay, hours saved, financial value and competitive prices are unknown. No defensible low/mid/high range, discount, tier or payment plan can be supplied from this fixture. Preserve one simple package. Psychological pricing and invented value anchors are not used.

Price explanation: USD 750 covers the defined session, brief, five draft hooks, outline and single feedback round. It does not buy a promised client or sales outcome. This explains the exchange; it does not prove value exceeds price.

## Known per-project economics
| Item | USD |
|---|---:|
| Revenue | 750.00 |
| Labor: 3.5 total hours × 70 | 245.00 |
| Per-project software | 25.00 |
| Payment processing | 22.50 |
| Total known costs | 292.50 |
| Contribution before omitted costs | 457.50 |

Contribution margin before omitted costs = 457.50 / 750 = 61%. This is not net profit. Acquisition cost, overhead allocation, taxes and refund costs remain unknown, never zero. Commissions/referrals, payment-plan terms, extra support cost treatment and cancellation-incurred or unrecoverable fees are unspecified. The 3.5 hours is supplied as total delivery time; confirm it includes the feedback round rather than double-counting or silently omitting support.

## Capacity scenario, not forecast or scarcity
At the internal ceiling of two completed projects/week: revenue USD 1,500/week; seven delivery hours/week; known costs USD 585/week; contribution USD 915/week before omitted costs. Demand, utilization and available places are unknown.

## Sensitivity and holds
For each additional delivery hour at the supplied rate, contribution falls USD 70 before omitted costs; one extra hour yields USD 387.50 (51.67%). This is a scenario, not expected cost. Let U be all additional per-project costs: contribution after those costs = USD 457.50 − U. USD 457.50 is the arithmetic ceiling for combined omitted costs at zero residual contribution, not a CAC budget or a profitability assurance.

Refund/cancellation policy: HOLD. Refund rate, conditions, cost reversibility and fee recovery unknown. No guarantee exposure, maximum loss or worst-case loss can be bounded. No refund policy is invented.

## Recommendation and validation
Retain USD 750 solely as fixture-authorized draft price; feasibility is provisional. First test comprehension and willingness to pay at this price without changing terms; then record actual total delivery time and omitted costs. Any later price/scope/guarantee change needs the real owner's separate approval and a new economics pass. No testing, outreach or selling was performed in this run.
'''})

hooks=[
'Fractional-operations consultants: put your existing offer into a one-page brief.',
'Have an offer you struggle to explain? Work through it in one 90-minute session.',
'Give your fractional-operations offer a clear starting point: one brief, five draft hooks and a landing-page outline.',
'Already served at least three paying clients? Bring your existing fractional-operations offer into focus.',
'Start your next offer draft with a focused session and one asynchronous feedback round.'
]
deliver('sales',{'HOOKS.md':f'''# Five Draft Hooks

{label}

Audience: {audience}. Aim: offer explanation and draft messaging; no growth results promised. Session length is not a guarantee of completed drafts at session end. Delivery and feedback terms remain those in OFFER.md v1.

'''+ '\n\n'.join(f'{i}. {h}' for i,h in enumerate(hooks,1))+'''

Use notes: 1 is the preferred outcome/callout opening for the page; 2 explores the pain angle; 3 explains the mechanism; 4 highlights prior-client eligibility (full US/solo criteria must accompany it); 5 explores bounded support. These are proposed uses, not published placements or measured winners. No proof hook is supported.
''',
'PITCH.md':f'''# Pitch Drafts

{label}

## Short
CEO Creative Offer Clarity Sprint helps {audience} turn an existing offer into a one-page brief and draft messaging to review and test.

## Medium
If explaining your fractional-operations offer feels harder than delivering it, bring the existing offer to a focused working session. The CEO Creative Offer Clarity Sprint combines one 90-minute working session with a one-page offer brief, five draft hooks, one landing-page outline, and one asynchronous feedback round within seven calendar days. For {audience}. USD 750, one-time. Draft deliverables arrive within five business days after complete intake. Review the sprint details.

## Long
You have an existing fractional-operations offer. This sprint focuses on putting its audience, intended outcome and scope into language you can review and test. It is for {audience}.

The working session is the place to discuss your offer. The one-page brief gives the draft a concise reference. The five draft hooks explore openings, and the landing-page outline organizes the message into sections. One asynchronous feedback round provides a bounded opportunity to refine the drafts.

{terms}

Review the sprint details and check eligibility before considering a purchase. Refund/cancellation terms must be settled before any real transaction.

## Owner handoff
Keep the existing name. Value Equation: concrete draft outcome; inspectable process rather than invented proof; conditional five-business-day draft delivery; bounded session and feedback with preparation effort unknown. No bonuses, inflated total value, urgency or scarcity. No alternate guarantees or name proliferation; fixed terms take precedence over generic template suggestions. Three likely objections: fit is limited to the stated eligibility; value is the defined work, with ROI unknown; the outline is not a built or published page. Mock pilot ratings are excluded from copy.
''',
'LANDING_PAGE.md':f'''# Landing-Page Draft

{label} This is a copy draft for review, not a live page. Section plan: hero → problem → outcome → solution → process → inclusions → demonstration → questions → policy → CTA. The sprint itself still includes only a landing-page outline.

## Hero
{hooks[0]}

CEO Creative Offer Clarity Sprint: a focused working session and draft messaging for {audience}.

CTA: Review the sprint details.

## Problem
If your service is easier to deliver than explain, start with the wording of the offer you already have. A vague description can leave the intended buyer, outcome and scope unclear.

## Outcome
Work toward a concise description of who the offer serves, what it aims to help with and what is included. Receive draft materials you can review and test.

## Solution and Process
Bring your existing offer to one 90-minute working session. Use the one-page offer brief as a reference for the five draft hooks and landing-page outline. One asynchronous feedback round is included within seven calendar days. Draft deliverables arrive within five business days after complete intake.

## What's Included
- One 90-minute working session: focused discussion of your existing offer.
- One-page offer brief: a concise draft reference.
- Five draft hooks: openings to compare and test.
- One landing-page outline: structure for developing a page.
- One asynchronous feedback round within seven calendar days: bounded draft refinement.

USD 750, one-time. No additional bonuses or standalone monetary values are claimed.

CTA: Review the sprint details.

## Demonstration Instead of Testimonials
Illustrative structure, not a customer result: “For [specific buyer], this offer helps with [defined problem] through [included work], with [clear boundaries].” No real testimonials or measured sales outcomes are supplied.

## Questions About Fit and Effort
**Who is eligible?** {audience}.

**What do I need to do?** Complete intake, attend the working session and participate in the included feedback round. Preparation time is not specified.

**Does this include a finished website?** The deliverable is one landing-page outline. Building and publishing are excluded.

**Will it bring clients?** No client/revenue/credit/funding/conversion outcomes are guaranteed.

**When do drafts arrive?** Draft deliverables arrive within five business days after complete intake. That is a delivery term, not a promised business-result date.

## Refund and Cancellation
Policy remains undecided. This draft is held for policy completion before any real purchase flow; no money-back or nonrefundable terms apply by implication.

## Next Step
Review whether the sprint fits your existing fractional-operations offer.

CTA: Review the sprint details.

## Owner Handoff — Not Customer Copy
Resolve refund/cancellation and define the start of the seven-calendar-day feedback window before real use. No booking, checkout, publishing or integrations were created. No credit repair, bureau reporting, loan placement or business filing services are included. Capacity is internal planning only. The illustrative structure is synthetic; mock pilot ratings must not be used as social proof.
'''})

deliver('root',{'OFFER_AUDIT.md':(ROOT/'output/REVISED_OFFER_CHECK.md').read_text(encoding='utf-8'),
'SUMMARY.md':f'''# Owner Summary — fictional draft, held

## Offer
{position} CEO Creative Offer Clarity Sprint serves {audience}.

{terms}

Value Equation: dream outcome is a concrete offer reference and draft messaging; perceived likelihood comes from an inspectable process, with no real results proof; time delay is five business days after complete intake for drafts; effort is one 90-minute session plus intake and a bounded feedback round, with preparation time unknown.

## Key Decisions
The fictional owner selected the USD 750 one-time price, scope, audience and timing in owner_terms.md. These are fixture-authorized draft terms only, never real business approval or evidence. Root retained them. Root's editorial proposal replaces vague growth wording with tangible offer explanation. No new coaching calls, bonuses, guarantees, unsupported results or scarcity claims were accepted.

Known delivery costs: USD 292.50/project; contribution USD 457.50/project and 61% before acquisition cost, overhead, taxes and refund costs. Those unknowns are not zero; net profitability is unknown. Refund/cancellation policy and exposure remain HOLD. Feedback-window start and preparation effort need clarification. Two projects/week is an internal ceiling, not available inventory. Mock pilot feedback is synthetic internal information, not customer proof or demand validation.

Execution: root fallback in this same conversation after native collaboration.spawn_agent was refused with: MODEL ROUTE GATE: exactly one TASK CLASS is required in the spawn message. No specialist worker ran. Model and effort observations: unknown. Requested specialist effort is recorded separately; no model/effort switch claimed.

Methods actually read: diagnostic and revised_check — audit-offer; revision — hormozi-offer; final_feasibility — pricing-strategy; sales copy — hormozi-pitch, hormozi-hooks and landing-page-copy. All used evidence-contract.md and commercial-feasibility.md. Orchestrator and orchestration.md were read. No market research or bonus task selected. Generic guarantee/price expansion prompts were overridden by fixed user terms. Same-context semantic review only; no separate-context review is claimed. Check QA_REPORT.md for the actual structural checker outcome; final commercial readiness remains held regardless of structural checks.

## Best Hook
{hooks[0]}

Chosen for audience and tangible deliverable specificity, not measured performance. Exactly five hooks are in HOOKS.md.

## Next Actions
1. Architect: obtain a real owner's refund/cancellation decision and clarify the feedback-window start before any commercial use; fixture terms are not approval.
2. Architect: reconcile acquisition, overhead, tax, refund and total delivery costs; verify the included feedback fits the 3.5-hour total before treating contribution as viable.
3. Architect: plan a low-cost comprehension check with eligible readers using this draft and fixed price; record understanding and willingness to pay before paid promotion, and seek separate real authorization before outreach or sales.
'''})
