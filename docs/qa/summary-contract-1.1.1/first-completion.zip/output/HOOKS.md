# Five Draft Hooks

Fictional fixture draft only. Terms from input/owner_terms.md; no real business approval or outcome evidence.

Audience: US solo fractional-operations consultants who already have an offer and at least three past paying clients. Aim: offer explanation and draft messaging; no growth results promised. Session length is not a guarantee of completed drafts at session end. Delivery and feedback terms remain those in OFFER.md v1.

1. Fractional-operations consultants: put your existing offer into a one-page brief.

2. Have an offer you struggle to explain? Work through it in one 90-minute session.

3. Give your fractional-operations offer a clear starting point: one brief, five draft hooks and a landing-page outline.

4. Already served at least three paying clients? Bring your existing fractional-operations offer into focus.

5. Start your next offer draft with a focused session and one asynchronous feedback round.

Use notes: 1 is the preferred outcome/callout opening for the page; 2 explores the pain angle; 3 explains the mechanism; 4 highlights prior-client eligibility (full US/solo criteria must accompany it); 5 explores bounded support. These are proposed uses, not published placements or measured winners. No proof hook is supported.
