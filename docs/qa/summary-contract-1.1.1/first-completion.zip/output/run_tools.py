import json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
RUN=ROOT/'output/runs/2026-11-04-clarity'
RUN.mkdir(parents=True,exist_ok=True)
def digest(p): return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def save(p,x): (ROOT/p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def read(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
BASE='output/runs/2026-11-04-clarity/'
def freeze(paths): return [dict(path=p,sha256=digest(p)) for p in paths]
def checkpoint(state,text):
 (ROOT/'output/CHECKPOINT.md').write_text('# Checkpoint\n\nStage B; fictional draft only; decisions v1.\n\n'+text+'\n',encoding='utf-8')
 state['checkpoint']=dict(path='output/CHECKPOINT.md',sha256=digest('output/CHECKPOINT.md'),decision_version=1)
 save(BASE+'RUN_STATE.json',state)
def accept(task_id,next_text):
 s=read(BASE+'RUN_STATE.json'); t=next(t for t in s['tasks'] if t['id']==task_id)
 for i in t['inputs']: assert digest(i['path'])==i['sha256'],i['path']
 for p in t['write_set']:
  assert (ROOT/p).is_file(),p
  s['artifacts'].append(dict(path=p,sha256=digest(p),decision_version=1,task=task_id,ready=False,high_risk=False))
 t['status']='done'; s['phase']='DRAFTING'; checkpoint(s,next_text)
def prepare(task_id):
 s=read(BASE+'RUN_STATE.json'); t=next(t for t in s['tasks'] if t['id']==task_id)
 paths=[x['path'] for x in s['tasks'][0]['inputs']]
 for dep in t['depends_on']: paths+=next(x for x in s['tasks'] if x['id']==dep)['write_set']
 t['inputs']=freeze(list(dict.fromkeys(paths)));t['status']='running';checkpoint(s,'Executing '+task_id+'; remaining tasks pending.')
 return t
if __name__=='__main__':
 sources=freeze(['input/owner_terms.md','input/existing_offer.md','input/costs_and_feedback.md','input/unapproved_brainstorm.md'])
 artifacts=['ORIGINAL_OFFER_AUDIT.md','OFFER.md','REVISED_OFFER_CHECK.md','OFFER_AUDIT.md','PRICING.md','PITCH.md','HOOKS.md','LANDING_PAGE.md','SUMMARY.md']
 save(BASE+'BRIEF.json',dict(schema_version=1,run_id='2026-11-04-clarity',offer_id='ceo-clarity',task='Audit and improve fictional offer; economics and sales drafts',stage='B',maturity='rough_offer',goal='Specific positioning without changing owner-selected fixture terms',requested_artifacts=artifacts,customer='US solo fractional-operations consultants with an existing offer and at least three past paying clients',offer_state='existing',facts=[dict(id='fixture',text='All data fictional; owner_terms.md is sole fixture term authority, never real business approval or outcome evidence.',source_type='synthetic',reference='input/owner_terms.md')],unknowns=['Refund/cancellation policy','Acquisition cost','Overhead allocation','Taxes','Refund costs','Market demand and sales effectiveness'],constraints=['No research or external actions','Fixed USD 750 one-time and exact owner scope','No new guarantees, bonuses, scarcity or unsupported proof','Drafts continue despite holds'],sources=sources,workspace_root=str(ROOT)))
 def field(value,kind='text',status='approved'):
  return dict(value=value,kind=kind,status=status,owner='fictional owner via owner_terms.md',updated='2026-11-04',authorization_ref='input/owner_terms.md',conditions=['Fixture draft authorization only; no real business approval or proof.'])
 fields={'price':field(dict(amount_minor=75000,currency='USD',cadence='one_time'),'money'),'eligibility':field('US solo fractional-operations consultants with an existing offer and at least three past paying clients','eligibility'),'scope':field(['one 90-minute working session','one-page offer brief','five draft hooks','one landing-page outline','one asynchronous feedback round within seven calendar days'],'list'),'delivery':field('Draft deliverables arrive within five business days after complete intake.'),'guarantee':field('No client/revenue/credit/funding/conversion outcomes are guaranteed.','guarantee'),'refund_cancellation':field(None,status='held'),'acquisition_cost':field(None,status='unknown'),'overhead':field(None,status='unknown'),'taxes':field(None,status='unknown'),'refund_cost':field(None,status='unknown')}
 save(BASE+'OFFER_DECISIONS.json',dict(schema_version=1,offer_id='ceo-clarity',version=1,parent_hash=None,fields=fields))
 save(BASE+'CLAIMS.json',dict(schema_version=1,claims=[]))
 specs=[('diagnostic','sub-value','diagnostic',[],['ORIGINAL_OFFER_AUDIT.md']),('revision','sub-offer','revision',['diagnostic'],['OFFER.md']),('revised_check','sub-value','revised_check',['revision'],['REVISED_OFFER_CHECK.md']),('pricing','sub-pricing','final_feasibility',['revision','revised_check'],['PRICING.md']),('sales','sub-sales','copy',['revision','pricing'],['PITCH.md','HOOKS.md','LANDING_PAGE.md']),('root','root','copy',['diagnostic','revision','revised_check','pricing','sales'],['OFFER_AUDIT.md','SUMMARY.md'])]
 tasks=[dict(id=i,role=r,mode=m,status='pending',depends_on=d,inputs=sources if i=='diagnostic' else [],write_set=['output/'+p for p in w]) for i,r,m,d,w in specs]
 tasks += [dict(id=i,role=r,status='not_requested',depends_on=[],inputs=[],write_set=[]) for i,r in [('market','sub-market'),('bonus','sub-value')]]
 s=dict(schema_version=1,run_id='2026-11-04-clarity',phase='ROUTED',tasks=tasks,routing=[dict(task=i,requested_effort='high' if r in ['sub-offer','sub-pricing'] else 'medium',observed_model='unknown',observed_effort='unknown') for i,r,_,_,_ in specs],decision_version=1,decision_hash=digest(BASE+'OFFER_DECISIONS.json'),artifacts=[],reviews=[],blockers=['Refund/cancellation undecided','Acquisition, overhead, taxes and refund costs unknown','Fictional fixture; real business validation absent'],qa_result='not_run')
 checkpoint(s,'Design: clarify buyer and tangible outputs; retain exact terms. Delegated stage B tasks next. No market research or bonus work requested.')
