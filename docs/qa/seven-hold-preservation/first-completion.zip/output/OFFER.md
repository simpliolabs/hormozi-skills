# Offer Clarity Sprint — revised fictional draft v1
Method: hormozi-offer; decision version 1. Owner authority: input/owner_terms.md, fictional acceptance data only. Positioning below is an editorial proposal, not real commercial approval. No market research was performed.

## 1. Business Snapshot
CEO Creative offers a bounded offer-writing sprint. Existing rough offer; channel, actual demand and sales performance unknown. The sprint organizes an existing offer into draft messaging assets.

## 2. Target Market
Solo fractional-operations consultants in the US who already have an offer and at least three past paying clients. These are owner-selected eligibility terms, not evidence of purchasing power or demand.

## 3. Ideal Customer Avatar
An eligible consultant who wants to explain an existing service more clearly. Hypothesized friction: a broad description makes it hard to state who should buy and what is included. Failed attempts, urgency, emotions and buyer language are unknown; no invented customer quotes.

## 4. Dream Outcome
A one-page offer brief describing buyer, problem, scope and positioning, with five draft hooks and a landing-page outline to develop from it. Feeling more confident explaining the offer is a hypothesis, not a guaranteed outcome. No status or revenue shift is promised.

## 5. Obstacles / 6. Solution Map
These ten obstacles are synthetic working hypotheses to validate. Solutions stay inside existing components, not ten new deliverables.
| Hypothesized obstacle | Work inside existing scope |
|---|---|
| Broad audience language | Clarify buyer wording in the brief without changing eligibility |
| Vague growth promise | State the deliverable outcome in the brief |
| Too many services in the description | Organize the existing scope during the session |
| Unclear buyer problem | Draft a problem statement during the session |
| Difficulty explaining differentiation | Draft positioning in the brief; no superiority claim |
| Trouble starting content | Five draft hooks |
| Unclear page sequence | One landing-page outline |
| Contradictory messaging across assets | Use the offer brief as a shared reference |
| Unanswered draft questions | One asynchronous feedback round within seven calendar days |
| Expectation of guaranteed sales | State limits clearly in the brief and copy |

## 7. Core Offer
Offer Clarity Sprint. Authorized draft price: USD 750, one-time.
Scope: one 90-minute working session, one-page offer brief, five draft hooks, one landing-page outline, and one asynchronous feedback round within seven calendar days.
Draft deliverables arrive within five business days after complete intake.
These are test process terms, not promises of business results. The seven-day feedback window's starting event is unspecified; clarify before operational use without inventing an anchor.
No credit repair, bureau reporting, loan placement or business filing services are included. No publishing or external system work.

## 8. Bonus Stack
Not requested. No added bonuses, calls, deliverables or ongoing support.

## 9. Value Stack
| Component | Practical role | Standalone monetary value |
|---|---|---|
| 90-minute working session | Make offer-writing decisions together | Unknown |
| One-page offer brief | Capture the offer in one reference | Unknown |
| Five draft hooks | Explore entry points for the message | Unknown |
| Landing-page outline | Organize the page's argument | Unknown |
| One async feedback round | Address draft questions within the stated window | Unknown |
Total monetary stacked value unknown. Price stays USD 750, one-time. No ROI, savings or inflated value anchor is supported. Economics follow this fixed version in PRICING.md.

## 10. Guarantee
No client/revenue/credit/funding/conversion outcomes are guaranteed.
Refund and cancellation policy remain undecided: HOLD. No money-back or nonrefundable term is implied. Additional guarantee options are intentionally not drafted because the owner explicitly held this decision.

## 11. Positioning
Three editorial directions considered within identical terms: (A) explain the existing offer in one page, (B) align hooks and page structure to one brief, (C) decide what the current offer includes. A leads because it makes the work product easiest to picture; B supports it; C risks implying deeper service redesign. This is an analyst recommendation, not a validated buyer preference.
Positioning: For solo fractional-operations consultants in the US with an existing offer and at least three past paying clients, the Offer Clarity Sprint organizes that offer into a one-page brief, five draft hooks and one landing-page outline through a 90-minute working session and one asynchronous feedback round within seven calendar days.
Category: bounded collaborative offer-writing service. Unsuitable for buyers needing a service built from scratch, implementation or guaranteed business results. No comparative performance advantage is claimed.

## 12. Messaging
Hooks: exactly five in HOOKS.md; no additional set here.
Benefits: a concise offer reference; draft ways to introduce it; an outline for explaining it on a page. These describe asset purposes, not measured results.
Draft CTA: Review whether the sprint fits your existing offer. CTA is text only.

## 13. Validation Notes
Validate understanding, willingness to pay and actual delivery effort before any real launch. Channel unknown. Two projects/week is internal planning only, never remaining inventory. Feedback-window anchor, refund/cancellation and full costs stay held; see summary for prioritized actions.
