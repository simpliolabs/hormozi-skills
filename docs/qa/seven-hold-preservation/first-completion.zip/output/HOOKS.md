# Five Draft Hooks
Fictional copy for review; not published or performance-tested. Method: hormozi-hooks. Audience: eligible US solo fractional-operations consultants with an existing offer and at least three past paying clients. Desired work product: a concise offer brief and related drafts. Pain and reactions are hypotheses. Draft-delivery timing is not a business-results timeline.

1. Fractional-operations consultants: put your existing offer into a one-page brief.
2. You have an offer. Is it clear who it is for and what is included?
3. Work on your existing offer in one focused 90-minute session.
4. Give your offer brief, five draft hooks and landing-page outline one consistent starting point.
5. Three or more past paying clients, but still wrestling with your offer wording? Start with the brief.

Selection: #1 is the recommended lead because it combines audience and visible work product. This is editorial judgment, not performance evidence. Suggested uses if later authorized: #1 page lead; #2 email opening; #3 session explainer; #4 process post; #5 fit introduction. No sends, ads or publication performed.
